-- MySQL dump 10.13  Distrib 9.5.0, for Win64 (x86_64)
--
-- Host: localhost    Database: feline_blog
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '817e5775-dfc6-11f0-ab9e-d4f32dda9255:1-1047';

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('1ff6de33-b000-4ed7-aaba-25e7d993b83d','0b2addd18cad41c6da8d6e71eaccd208bd8d9a9a8b0f6c9efe144d95535e08db','2025-12-26 13:58:34.442','20251226135834_init',NULL,NULL,'2025-12-26 13:58:34.217',1),('54542b00-12e3-462a-9145-da68aa2f3c0f','519cf637491a1166ba1bd44a8e21c3cf69145e6094916285d363b533ac694745','2025-12-24 11:43:53.388','20251224114353_init',NULL,NULL,'2025-12-24 11:43:53.063',1),('5a6f4c6b-7988-4f52-b242-9d501fe497cc','a66fb4d9037aa1761e46b96aa210eb5314340a296b93d64b7acff5a0c4396ca4','2025-12-24 09:57:38.757','20251224095738_init',NULL,NULL,'2025-12-24 09:57:38.531',1),('7a61d819-039e-4a2f-9a04-6f0cc1e2816a','92ff06acaf8e1ea9a8e639c31d7a1a456cf07ec48ef2fd0b868edf00506f6b06','2025-12-24 02:58:40.584','20251224025839_init',NULL,NULL,'2025-12-24 02:58:39.864',1),('7bdeb472-85b3-4742-8ce1-53a4ee8cfae7','73b1e776716c2cf17ef925b638b96068f9ee545190a9aea243d7dfbd7d377803','2025-12-24 12:35:49.106','20251224123549_init',NULL,NULL,'2025-12-24 12:35:49.030',1),('935fef33-e442-4b81-b5bf-de0d344dc102','6fb17eff88157a61b8276d06b3a6de12db55c493747e1c89d7c000a9ab826fc0',NULL,'20251231052508_init','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251231052508_init\n\nDatabase error code: 1452\n\nDatabase error:\nCannot add or update a child row: a foreign key constraint fails (`feline_blog`.`#sql-1cf8_82`, CONSTRAINT `Blog_authorId_fkey` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)\n\nPlease check the query number 11 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20251231052508_init\"\n             at schema-engine\\connectors\\sql-schema-connector\\src\\apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name=\"20251231052508_init\"\n             at schema-engine\\commands\\src\\commands\\apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine\\core\\src\\state.rs:246',NULL,'2025-12-31 05:25:08.712',0),('ca503e45-083e-4801-8b5d-634f51e22b27','d13da729a684689b9315e9f52f3f4229f1e0d00b745049e664c3e16b13384bc7','2025-12-26 10:54:34.589','20251226105434_init',NULL,NULL,'2025-12-26 10:54:34.353',1),('d87d503f-7c9b-466d-a25f-12ecd724cff0','8b541c1ce68d5c0808284b029fbb848f1783bbbf8bd965e13f5beeb148567e0b','2025-12-23 06:53:18.322','20251223065318_init',NULL,NULL,'2025-12-23 06:53:18.113',1),('d993db43-5db6-48a7-b193-171e7afa863d','b9f54c0c3f4e75bce0d6219c9b818f0ac76f9d9945e1d1bb06bb8528b77f4d41','2025-12-26 14:00:09.566','20251226140009_init',NULL,NULL,'2025-12-26 14:00:09.486',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (5,'test-user','test','123123321','2025-12-24 09:24:52.641','2025-12-24 09:28:10.308',0),(6,'test-user','test no user','123','2025-12-24 09:33:56.916','2025-12-24 09:33:56.916',0),(7,'test-user','321','1231231231111','2025-12-24 09:39:15.958','2025-12-24 09:39:30.601',0),(8,'test-user','321','123321123','2025-12-24 09:39:39.976','2025-12-24 09:39:39.976',0),(9,'test-user','321','123','2025-12-24 09:40:13.807','2025-12-24 09:40:13.807',0),(10,'test-user','321','qweewqewq11  \n\n3242423','2025-12-24 09:42:53.238','2025-12-24 09:43:07.341',0),(11,'test-user','test tags','test tagstest tagstest tags  \n\ntest tagstest tags  \ntest tags  \ntest tags  \ntest tagstest tags  \n# 12   \n12321421321','2025-12-26 14:19:02.184','2025-12-26 14:19:02.184',0),(12,'test-user','123','123321','2025-12-26 14:24:41.315','2025-12-26 14:24:41.315',0),(13,'test-user','test add new multi tags','test add new multi tagstest add new multi tags  \ntest add new multi tags  \n# test add new multi tags  \n### test add new multi tags  \n- test add new multi tags  \n- test add new multi tags  \n123321','2025-12-26 14:32:27.852','2025-12-26 15:20:50.703',0);
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sessionToken` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_sessionToken_key` (`sessionToken`),
  KEY `sessions_userId_fkey` (`userId`),
  CONSTRAINT `sessions_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tag_content_key` (`content`),
  UNIQUE KEY `Tag_userId_content_key` (`userId`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'test','oklch(49.6% 0.265 301.924)','2025-12-24 12:12:01.966','2025-12-27 10:10:14.259','test-user'),(2,'111','oklch(78.5% 0.115 274.713)','2025-12-24 12:14:02.013','2025-12-25 14:51:00.612','test-user'),(3,'321','oklch(66.7% 0.295 322.15)','2025-12-24 12:14:02.013','2025-12-25 14:28:13.752','test-user'),(4,'132','oklch(82.8% 0.111 230.318)','2025-12-24 12:14:02.013','2025-12-24 12:14:02.013','test-user'),(5,'123','','2025-12-24 12:14:56.283','2025-12-25 14:51:06.566','test-user'),(6,'321321','oklch(96.9% 0.016 293.756)','2025-12-24 12:14:56.283','2025-12-24 12:14:56.283','test-user'),(7,'qwe','oklch(78.9% 0.154 211.53)','2025-12-24 12:21:34.188','2025-12-24 12:21:34.188','test-user'),(8,'add','oklch(85.5% 0.138 181.071)','2025-12-25 14:14:53.533','2025-12-25 14:14:53.533','test-user'),(9,'add Todo','oklch(71.2% 0.194 13.428)','2025-12-25 14:15:47.003','2025-12-25 14:15:47.003','test-user'),(10,'new Tag','oklch(51.8% 0.253 323.949)','2025-12-25 14:19:55.282','2025-12-26 15:20:50.683','test-user'),(11,'new Tag1','oklch(82.8% 0.111 230.318)','2025-12-25 14:22:02.491','2025-12-25 14:22:02.491','test-user'),(12,'test add ','oklch(90.1% 0.058 230.902)','2025-12-25 14:49:01.636','2025-12-25 14:49:01.636','test-user'),(13,'Todo','oklch(54.6% 0.245 262.881)','2025-12-26 07:06:13.628','2025-12-27 07:03:58.573','test-user'),(14,'代码','','2025-12-26 07:06:13.628','2025-12-26 15:25:23.915','test-user'),(15,'Tag','oklch(70.4% 0.14 182.503)','2025-12-26 13:54:39.948','2025-12-27 10:10:14.260','test-user'),(16,'Blog','oklch(63.7% 0.237 25.331)','2025-12-26 13:54:39.946','2025-12-30 07:51:06.091','test-user'),(17,'test add Tag','','2025-12-26 14:24:41.295','2025-12-26 14:24:41.295','test-user'),(18,'new Tag 2','oklch(50% 0.134 242.749)','2025-12-26 15:20:50.684','2025-12-26 15:20:50.684','test-user'),(19,'设计','','2025-12-26 15:27:39.947','2025-12-26 15:27:39.947','test-user'),(20,'页面','oklch(86.5% 0.127 207.078)','2025-12-26 15:28:03.635','2025-12-30 08:08:48.093','test-user'),(21,'日历','oklch(57.7% 0.245 27.325)','2025-12-27 07:02:51.587','2025-12-27 07:02:51.587','test-user'),(22,'布局','oklch(45.5% 0.188 13.697)','2025-12-30 08:08:48.090','2025-12-30 08:08:48.090','test-user'),(23,'组件','oklch(59.1% 0.293 322.896)','2025-12-31 04:54:18.398','2025-12-31 04:58:48.372','test-user');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagsonblogs`
--

DROP TABLE IF EXISTS `tagsonblogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagsonblogs` (
  `blogId` int NOT NULL,
  `tagId` int NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `assignedBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`blogId`,`tagId`),
  KEY `TagsOnBlogs_tagId_fkey` (`tagId`),
  CONSTRAINT `TagsOnBlogs_blogId_fkey` FOREIGN KEY (`blogId`) REFERENCES `blog` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TagsOnBlogs_tagId_fkey` FOREIGN KEY (`tagId`) REFERENCES `tag` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagsonblogs`
--

LOCK TABLES `tagsonblogs` WRITE;
/*!40000 ALTER TABLE `tagsonblogs` DISABLE KEYS */;
INSERT INTO `tagsonblogs` VALUES (12,17,'2025-12-26 14:24:41.313','test-user'),(13,10,'2025-12-26 15:20:50.701','test-user'),(13,14,'2025-12-26 15:20:50.701','test-user'),(13,16,'2025-12-26 15:20:50.701','test-user'),(13,18,'2025-12-26 15:20:50.701','test-user');
/*!40000 ALTER TABLE `tagsonblogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagsontodos`
--

DROP TABLE IF EXISTS `tagsontodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagsontodos` (
  `todoId` int NOT NULL,
  `tagId` int NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `assignedBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`todoId`,`tagId`),
  KEY `TagsOnTodos_tagId_fkey` (`tagId`),
  CONSTRAINT `TagsOnTodos_tagId_fkey` FOREIGN KEY (`tagId`) REFERENCES `tag` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TagsOnTodos_todoId_fkey` FOREIGN KEY (`todoId`) REFERENCES `todo` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagsontodos`
--

LOCK TABLES `tagsontodos` WRITE;
/*!40000 ALTER TABLE `tagsontodos` DISABLE KEYS */;
INSERT INTO `tagsontodos` VALUES (2,1,'2025-12-24 12:12:01.960','test-user'),(4,2,'2025-12-24 12:14:56.282','test-user'),(4,5,'2025-12-24 12:14:56.282','test-user'),(4,6,'2025-12-24 12:14:56.282','test-user'),(5,5,'2025-12-24 12:15:26.053','test-user'),(7,3,'2025-12-24 12:16:01.817','test-user'),(8,1,'2025-12-24 12:16:15.784','test-user'),(8,3,'2025-12-24 12:16:15.784','test-user'),(9,1,'2025-12-24 12:17:56.859','test-user'),(10,1,'2025-12-24 12:18:46.057','test-user'),(11,7,'2025-12-24 12:21:34.187','test-user'),(12,1,'2025-12-24 12:23:23.823','test-user'),(13,1,'2025-12-24 12:40:31.307','test-user'),(14,5,'2025-12-24 12:40:43.931','test-user'),(15,2,'2025-12-24 12:40:57.827','test-user'),(20,5,'2025-12-25 14:51:06.579','test-user'),(21,13,'2025-12-26 07:06:13.646','test-user'),(21,14,'2025-12-26 07:06:13.646','test-user'),(22,14,'2025-12-26 13:54:39.979','test-user'),(22,15,'2025-12-26 13:54:39.979','test-user'),(22,16,'2025-12-26 13:54:39.979','test-user'),(23,14,'2025-12-26 15:25:23.934','test-user'),(23,15,'2025-12-26 15:25:23.934','test-user'),(24,13,'2025-12-26 15:27:39.963','test-user'),(24,19,'2025-12-26 15:27:39.963','test-user'),(25,15,'2025-12-26 15:28:03.651','test-user'),(25,20,'2025-12-26 15:28:03.651','test-user'),(26,16,'2025-12-26 15:29:13.663','test-user'),(26,20,'2025-12-26 15:29:13.663','test-user'),(27,13,'2025-12-26 15:29:42.067','test-user'),(27,20,'2025-12-26 15:29:42.067','test-user'),(28,16,'2025-12-30 07:51:06.134','test-user'),(28,20,'2025-12-30 07:51:06.134','test-user'),(29,21,'2025-12-27 07:02:51.638','test-user'),(30,13,'2025-12-27 07:03:58.599','test-user'),(30,15,'2025-12-27 07:03:58.599','test-user'),(31,1,'2025-12-27 10:10:14.285','test-user'),(31,15,'2025-12-27 10:10:14.285','test-user'),(36,20,'2025-12-30 08:08:48.112','test-user'),(36,22,'2025-12-30 08:08:48.112','test-user'),(37,23,'2025-12-31 04:54:18.438','test-user'),(38,23,'2025-12-31 04:58:48.390','test-user');
/*!40000 ALTER TABLE `tagsontodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `todo`
--

DROP TABLE IF EXISTS `todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT '0',
  `createAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  `finishedAt` datetime(3) NOT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todo`
--

LOCK TABLES `todo` WRITE;
/*!40000 ALTER TABLE `todo` DISABLE KEYS */;
INSERT INTO `todo` VALUES (2,'test add todo',0,'2025-12-24 12:12:01.966','2025-12-26 07:05:31.496','2025-12-26 07:05:31.496',1,'test-user'),(3,'test add multi tags',0,'2025-12-24 12:14:02.013','2025-12-26 07:05:31.023','2025-12-26 07:05:31.023',1,'test-user'),(4,'test add exist tags',0,'2025-12-24 12:14:56.283','2025-12-24 12:54:17.020','2025-12-24 12:54:17.020',1,'test-user'),(5,'123231',0,'2025-12-24 12:15:26.054','2025-12-24 12:54:24.143','2025-12-24 12:54:24.143',1,'test-user'),(6,'123',0,'2025-12-24 12:15:44.178','2025-12-26 07:05:30.532','2025-12-26 07:05:30.532',1,'test-user'),(7,'321',0,'2025-12-24 12:16:01.818','2025-12-25 14:07:40.195','2025-12-25 14:07:40.195',1,'test-user'),(8,'123',1,'2025-12-24 12:16:15.785','2025-12-25 08:13:48.035','2025-12-25 08:13:48.035',1,'test-user'),(9,'123',0,'2025-12-24 12:17:56.859','2025-12-24 12:54:19.219','2025-12-24 12:54:19.219',1,'test-user'),(10,'tes',1,'2025-12-24 12:18:46.058','2025-12-24 12:54:28.794','2025-12-24 12:54:28.794',1,'test-user'),(11,'123',0,'2025-12-24 12:21:34.188','2025-12-24 12:54:15.278','2025-12-24 12:54:15.278',1,'test-user'),(12,'123312',1,'2025-12-24 12:23:23.824','2025-12-25 08:13:47.665','2025-12-25 08:13:47.665',1,'test-user'),(13,'123',1,'2025-12-24 12:40:31.312','2025-12-25 08:13:47.105','2025-12-25 08:13:47.105',1,'test-user'),(14,'123',0,'2025-12-24 12:40:43.933','2025-12-24 12:54:13.220','2025-12-24 12:54:13.220',1,'test-user'),(15,'111',0,'2025-12-24 12:40:57.828','2025-12-24 12:45:39.107','2025-12-24 12:45:39.107',1,'test-user'),(16,'1232123123',1,'2025-12-25 14:14:53.556','2025-12-26 07:05:30.144','2025-12-26 07:05:30.144',1,'test-user'),(17,'123 add ',0,'2025-12-25 14:15:47.019','2025-12-26 07:05:29.663','2025-12-26 07:05:29.663',1,'test-user'),(18,'test add multi tags',0,'2025-12-25 14:19:55.300','2025-12-26 07:05:29.217','2025-12-26 07:05:29.217',1,'test-user'),(19,'1231',0,'2025-12-25 14:49:01.652','2025-12-26 07:05:24.546','2025-12-26 07:05:24.546',1,'test-user'),(20,'111',1,'2025-12-25 14:50:50.643','2025-12-26 07:05:23.536','2025-12-26 07:05:23.536',1,'test-user'),(21,'TodoEditor代码优化',1,'2025-12-26 07:06:13.650','2025-12-26 07:06:15.303','2025-12-26 07:06:15.303',0,'test-user'),(22,'Blog 添加 tag 及 tag 编辑面板',1,'2025-12-26 13:54:39.986','2025-12-27 10:12:54.659','2025-12-27 10:12:54.659',0,'test-user'),(23,'tag 增加常用建议',0,'2025-12-26 15:25:23.935','2025-12-26 15:25:23.935','2025-12-26 15:25:23.935',0,'test-user'),(24,'todo 增加目标模式，这种模式下，会设定最终目标，每次完成该 todo 都会提示添加该目标的下一步骤，即创建新的 todo。',0,'2025-12-26 15:27:39.964','2025-12-26 15:27:39.964','2025-12-26 15:27:39.964',0,'test-user'),(25,'增加 tag 列表页',0,'2025-12-26 15:28:03.653','2025-12-26 15:28:03.653','2025-12-26 15:28:03.653',0,'test-user'),(26,'blog 页面添加编辑栏，支持删除，收藏等操作。',0,'2025-12-26 15:29:13.664','2025-12-26 15:29:13.664','2025-12-26 15:29:13.664',0,'test-user'),(27,'todo 页面增加搜索栏，支持筛选等操作',1,'2025-12-26 15:29:42.068','2025-12-27 15:56:32.262','2025-12-27 15:56:32.262',0,'test-user'),(28,'blog 列表页面添加搜索栏，支持筛选等操作。',1,'2025-12-26 15:30:39.466','2025-12-30 07:51:07.937','2025-12-30 07:51:07.937',0,'test-user'),(29,'日期组件实现 - 初始框架搭建',0,'2025-12-27 07:02:51.642','2025-12-27 07:02:51.642','2025-12-27 07:02:51.642',0,'test-user'),(30,'todo 增加“优先级” tag',0,'2025-12-27 07:03:58.600','2025-12-27 07:03:58.600','2025-12-27 07:03:58.600',0,'test-user'),(31,'大小写敏感测试 Tag',0,'2025-12-27 10:10:14.288','2025-12-27 10:12:30.594','2025-12-27 10:12:30.594',1,'test-user'),(32,'添加测试2',0,'2025-12-27 10:10:43.076','2025-12-27 10:12:29.070','2025-12-27 10:12:29.070',1,'test-user'),(33,'tag 测试1',0,'2025-12-27 10:10:51.205','2025-12-27 10:12:28.187','2025-12-27 10:12:28.187',1,'test-user'),(34,'tag 1',0,'2025-12-27 10:11:09.830','2025-12-27 10:12:27.197','2025-12-27 10:12:27.197',1,'test-user'),(35,'123',0,'2025-12-27 12:52:29.505','2025-12-27 12:52:31.809','2025-12-27 12:52:31.809',1,'test-user'),(36,'重新调整主要布局容器,考虑让每个页面自主决定篇幅的使用。',0,'2025-12-30 08:08:48.114','2025-12-30 08:08:52.552','2025-12-30 08:08:52.552',0,'test-user'),(37,'新组件: 抽屉式内容展示',0,'2025-12-31 04:54:18.442','2025-12-31 04:54:18.442','2025-12-31 04:54:18.442',0,'test-user'),(38,'不规则图片框',0,'2025-12-31 04:58:48.391','2025-12-31 04:58:48.391','2025-12-31 04:58:48.391',0,'test-user');
/*!40000 ALTER TABLE `todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('USER','ADMIN','ROOT','VISITOR') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_key` (`email`),
  UNIQUE KEY `users_phone_key` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_tokens` (
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`identifier`,`token`),
  UNIQUE KEY `verification_tokens_token_key` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 13:54:33
