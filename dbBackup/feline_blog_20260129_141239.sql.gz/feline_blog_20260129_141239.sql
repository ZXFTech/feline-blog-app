-- MySQL dump 10.13  Distrib 9.5.0, for Win64 (x86_64)
--
-- Host: localhost    Database: feline_blog
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '817e5775-dfc6-11f0-ab9e-d4f32dda9255:1-3508';

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('03ae503e-3136-4658-99f3-cb017a1222ba','4eb57f91130b4154fddb7afb004842fe9636296795173992d52a9020d5d96387','2026-01-19 22:57:04.845','20260119225704_init',NULL,NULL,'2026-01-19 22:57:04.639',1),('24b292e5-4263-47d4-a069-5f0fa2eb59cd','519cf637491a1166ba1bd44a8e21c3cf69145e6094916285d363b533ac694745','2025-12-31 05:57:00.890','20251224114353_init',NULL,NULL,'2025-12-31 05:57:00.559',1),('2635e600-a05b-47da-977b-246659f0f211','a66fb4d9037aa1761e46b96aa210eb5314340a296b93d64b7acff5a0c4396ca4','2025-12-31 05:57:00.554','20251224095738_init',NULL,NULL,'2025-12-31 05:57:00.352',1),('56570668-dcd9-4309-b46e-1ec8078163f4','2eb2d8a71a45daa94dbd73dd9fdbf8078fdae3d3d5530e08f7cb952295d12110','2026-01-25 08:46:35.496','20260125084635_init',NULL,NULL,'2026-01-25 08:46:35.449',1),('58481006-bc2b-4e01-b2df-7bb1a683c507','6efdbfb34c85265beb2426d17a79d07db9577452a3d48cf0049c917e0f1b39c1','2025-12-31 06:32:30.946','20251231063230_init',NULL,NULL,'2025-12-31 06:32:30.835',1),('77dac00c-39fc-43e8-959b-ddd12a34fc00','b9f54c0c3f4e75bce0d6219c9b818f0ac76f9d9945e1d1bb06bb8528b77f4d41','2025-12-31 05:57:01.520','20251226140009_init',NULL,NULL,'2025-12-31 05:57:01.373',1),('8033d6ed-e863-49b8-8c0a-07f6f25186c2','6fb17eff88157a61b8276d06b3a6de12db55c493747e1c89d7c000a9ab826fc0','2025-12-31 05:57:02.174','20251231052508_init',NULL,NULL,'2025-12-31 05:57:01.526',1),('8db503ca-10ea-437e-a4e3-ca05015b7983','1d402fc0b3ab2ab37b9d2bf33277d43331b0c0d460afbbbd7652cb18fa843479','2026-01-21 07:47:13.448','20260121074713_init',NULL,NULL,'2026-01-21 07:47:13.371',1),('902580db-3019-4827-929e-2678016c4c0d','457ebaa9ab09e3411e81261442dd31c319f7ab766ceebd15500b2df93441248d','2026-01-26 03:34:30.174','20260126033429_init',NULL,NULL,'2026-01-26 03:34:29.755',1),('a912f02e-4c75-4eeb-8ede-db7939bb5bad','8938ba67eebdd5bbcb98d10ec596026b3ed2ab0bc884354abb85b51f2fb50609','2026-01-20 01:55:15.157','20260120015515_init',NULL,NULL,'2026-01-20 01:55:15.058',1),('b6b3281e-59d2-4dda-a6a5-76bb0e9b8c86','28c8d30ef62ccd0fcaec5ce410467f36d36b36fb85f96bb6de3a1707b52a6478','2025-12-31 05:57:00.346','20251224025839_init',NULL,NULL,'2025-12-31 05:56:59.685',1),('c0232fbc-db13-424a-ba33-93dd05b01687','73b1e776716c2cf17ef925b638b96068f9ee545190a9aea243d7dfbd7d377803','2025-12-31 05:57:00.938','20251224123549_init',NULL,NULL,'2025-12-31 05:57:00.896',1),('c3395a69-8c5e-4dd5-ba59-acb7b30caecb','0b2addd18cad41c6da8d6e71eaccd208bd8d9a9a8b0f6c9efe144d95535e08db','2025-12-31 05:57:01.367','20251226135834_init',NULL,NULL,'2025-12-31 05:57:01.156',1),('d04c4378-ba37-467f-8f88-f2a1336bbef5','afac8cebbf88f37a8713ea141b617fb8b4de54577d6acef45c4f02c714a470cb','2026-01-15 01:57:22.741','20260115015722_init',NULL,NULL,'2026-01-15 01:57:22.370',1),('e3c4c203-34d7-4bcb-963f-5d0acd3baabd','2851229a07cef74e2e8c6c88ce4618ecc510ccaaaac0394402748a3dbd4145fc','2025-12-31 05:56:59.679','20251223065318_init',NULL,NULL,'2025-12-31 05:56:59.478',1),('f923d4b4-b9da-43c3-98a1-7750f84d1f5b','0a68904ed073fd52be830302864abaad2930592d078a0394bd64ce2509eb12a4','2026-01-20 02:13:06.837','20260120021306_init',NULL,NULL,'2026-01-20 02:13:06.763',1),('fedd102b-f9ad-4059-93c7-15fdc51fa957','d13da729a684689b9315e9f52f3f4229f1e0d00b745049e664c3e16b13384bc7','2025-12-31 05:57:01.150','20251226105434_init',NULL,NULL,'2025-12-31 05:57:00.943',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `favoriteCount` int NOT NULL DEFAULT '0',
  `likeCount` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Blog_authorId_fkey` (`authorId`),
  CONSTRAINT `Blog_authorId_fkey` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (16,'cmkarwq5v0003b47kn18mszur','一步一个库 —— 加速 JavaScript 系统','📖 大多数主流的库都可以通过避免不必要的类型转换或者在函数中创建函数来提高性能。  \n  \n第一部分：PostCSS, SVGO 等  \n尽管当前的主要趋势是用 Rust, Go 等其他语言来重写 JavaScript 的构建工具, 但目前的基于 JavaScript 的工具的性能仍然有很大的进步空间。在一个典型前端项目中，构建流水线通常由 **许多不同的工具协同工作** 组成。但是，工具的多样化使得工具维护者更加难以定位其中的性能瓶颈，因为他们必须清楚自己的工具会经常和哪些其他的工具组合使用。  \n尽管从纯语言性能的角度来看，JavaScript 确实不如 Rust 或 Go，但现有的 JavaScript 工具仍然有着相当大的优化空间。JavaScript 确实更慢一些，但不至于像现在这样与它们拉开如此大的差距。毕竟，如今的 JIT 引擎的性能已经很惊人了。  \n出于好奇，我花了些时间对一些常见的基于 JavaScript 的工具进行了性能分析，来大致看下其中的时间都消耗在哪里。首先从 PostCSS —— 一个非常流行的、几乎用于所有 CSS 相关处理的解析器和转换器说起。  \n  \n# 在 PostCss 中节省 4.6 秒的性能开销  \n  \n有一个非常有用的插件：[postCss-custom-properties](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-custom-properties)，它为旧版浏览器提供了对 CSS 自定义属性的基础支持。然而，在性能分析的调用轨迹中，它却异常显眼：仅它内部使用的一条正则表达式就消耗了高达 4.6 秒的时间。这看起来相当反常。  \n  \n![Picture of a flamegraph showing that the regex alone takes 4.6s](https://marvinh.dev/media/js-tools-postcss-custom-properties.png)  \n  \n这条正则表达式看起来很可疑，它的作用似乎是在查找某个特定的注释内容，以改变插件的行为，这种用法和 eslint 用于禁用特定规则的注释上非常相似。虽然在他们的 README 中没有提及，但在查看源码后证实了这个推测。  \n  \n```jsx  \nfunction isBlockIgnored(ruleOrDeclaration) {  \n	const rule = ruleOrDeclaration.selector  \n		? ruleOrDeclaration  \n		: ruleOrDeclaration.parent;  \n  \n	return /(!\\\\s*)?postcss-custom-properties:\\\\s*off\\\\b/i.test(rule.toString());  \n}  \n```  \n  \n`rule.toString()`引起了我的注意。在做性能优化是，凡是涉及类型转换的地方都值得重点关注，因为只要能避免类型转换，就几乎一定能节省时间。在这个场景中，有趣的地方在于 rule 变量始终是一个带有自定义 toString 方法的对象。他一开始就不是一个字符串，这意味着为了能让正则表达式正确匹配，我们不可避免的要付出一次序列化的性能成本。根据以往的经验我知道，对大量段字符串进行匹配，远比对少量长字符串进行匹配要慢的多。这正是一个**非常典型、几乎在“等着被优化”的性能热点**。  \n这段代码最令人担忧的点在于：无论输入文件中是否包含 PostCSS 注释，每个文件都必须为此付出这些性能开销。既然我们已经知道在长字符上进行正则匹配，要比在大量短字符反复运行正则匹配和序列化更高效。所以，如果能事先知道一个文件不包含任何 PostCSS 注释，就完全没有必要去调用 isBlockIgnored 这个函数。  \n  \n在这一修复上线后，构建时间直接大幅缩短了 4.6 秒，相当惊人。  \n  \n# 优化 SVG 压缩速度  \n  \n接下来要看的是 SVGO，一个用于压缩 SVG 文件的库。他非常出色，几乎是大量使用 SVG 图标的项目的标配工具。不过，从 CPU 性能分析结果来看，仅 SVG 压缩这一过程就耗费了 3.1 秒。这个过程还能再加速吗？  \n  \n在进一步审查性能分析数据时，一个函数格外显眼：strongRound。更值得注意的是，这个函数调用后面经常跟随着一次小规模的 GC 清理（见那些小小的红色方块标记）。  \n  \n![image.png](https://marvinh.dev/media/js-tools-stringifyNumber.png)  \n  \n我的好奇心被激起来了，让我们直接在 GitHub 上看看它的源码。  \n  \n```jsx  \n/**  \n * Decrease accuracy of floating-point numbers  \n * in path data keeping a specified number of decimals.  \n * Smart rounds values like 2.3491 to 2.35 instead of 2.349.  \n */  \nfunction strongRound(data: number[]) {  \n	for (var i = data.length; i-- > 0; ) {  \n		if (data[i].toFixed(precision) != data[i]) {  \n			var rounded = +data[i].toFixed(precision - 1);  \n			data[i] =  \n				+Math.abs(rounded - data[i]).toFixed(precision + 1) >= error  \n					? +data[i].toFixed(precision)  \n					: rounded;  \n		}  \n	}  \n	return data;  \n}  \n```  \n  \nAha！原来这是一个用于压缩数字的函数，而在任何典型的 SVG 文件中，数字的数量都很庞大。这个函数接受一个数字数组，且预期会直接修改数组中的元素。让我们关注下他的实现中所使用的变量类型。随着进一步观察可以发现，代码中存在着大量字符串和数字来回转换的情况。  \n  \n```jsx  \nfunction strongRound(data: number[]) {  \n	for (var i = data.length; i-- > 0; ) {  \n		// Comparison between string and number -> string is cast to number  \n		if (data[i].toFixed(precision) != data[i]) {  \n			// Creating a string from a number that\'s casted immediately  \n			// back to a number  \n			var rounded = +data[i].toFixed(precision - 1);  \n			data[i] =  \n				// Another number that is casted to a string and directly back  \n				// to a number again  \n				+Math.abs(rounded - data[i]).toFixed(precision + 1) >= error  \n					? // This is the same value as in the if-condition before,  \n					  // just casted to a number again  \n					  +data[i].toFixed(precision)  \n					: rounded;  \n		}  \n	}  \n	return data;  \n}  \n```  \n  \n类似于给数字进行四舍五入这种事，本质上可以只通过数学运算来完成，没有必要把数字转换成字符串。一般来说，相当一部分性能优化的核心思想，就是尽可能用数值运算来表达问题，核心原因就在于：CPU 在数值运算方面的效率极高。通过对代码进行一些调整，我们就可以始终停留在”数字层面“来避免将其转换成字符串所带来的开销。  \n  \n```jsx  \n// Does the same as `Number.prototype.toFixed` but without casting  \n// the return value to a string.  \nfunction toFixed(num, precision) {  \n	const pow = 10 ** precision;  \n	return Math.round(num * pow) / pow;  \n}  \n  \n// Rewritten to get rid of all the string casting and call our own  \n// toFixed() function instead.  \nfunction strongRound(data: number[]) {  \n	for (let i = data.length; i-- > 0; ) {  \n		const fixed = toFixed(data[i], precision);  \n		// Look ma, we can now use a strict equality comparison!  \n		if (fixed !== data[i]) {  \n			const rounded = toFixed(data[i], precision - 1);  \n			data[i] =  \n				toFixed(Math.abs(rounded - data[i]), precision + 1) >= error  \n					? fixed // We can now reuse the earlier value here  \n					: rounded;  \n		}  \n	}  \n	return data;  \n}  \n```  \n  \n再次运行性能分析后可以确认，构建时间缩短了约 1.4 秒！我已经为此提交了一个 PR。  \n  \n# 短字符上的正则表达式（第二部分）  \n  \n在 strongRound 附近还有一个函数看起来很可疑，它的执行时间接近整整一秒（0.9秒）  \n  \n![image.png](https://marvinh.dev/media/js-tools-stringifyNumber.png)  \n  \n和 strongRound 类似，这个函数同样用于压缩数字，但额外做了一件事：当数字带有小数部分，且绝对值介于正负 1 之间，可以去掉前置的 0。如 0.5 被压缩成 .5，-0.2 被压缩成 -.2。尤其是最后一行看起来很有意思。  \n  \n```jsx  \nconst stringifyNumber = (number: number, precision: number) => {  \n	// ...snip  \n  \n	// remove zero whole from decimal number  \n	return number.toString().replace(/^0\\./, \".\").replace(/^-0\\./, \"-.\");  \n};  \n```  \n  \n这里的代码是将数字转换成字符串，然后对其进行正则匹配。这个由数字转换的字符串基本可以确定会是一个段字符串。同时我们知道一个数字不可能同时满足 `n > 0 && n < 1` 和`n > -1 && n < 0` 这两个条件，就算是 NaN 也做不到。由此我们可以推断出，每次只会有一个正则被匹配到，或者都不会被匹配到，但绝不可能两个都匹配。所以至少有一次 .replace 调用是在做无用功。  \n  \n我们可以通过手动区分这些情况来进行优化。只有在明确知道数字存在前置 0 的情况下，才执行替换逻辑。这些数值判断要比执行正则搜索要快得多。  \n  \n```jsx  \nconst stringifyNumber = (number: number, precision: number) => {  \n	// ...snip  \n  \n	// remove zero whole from decimal number  \n	const strNum = number.toString();  \n	// Use simple number checks  \n	if (0 < num && num < 1) {  \n		return strNum.replace(/^0\\./, \".\");  \n	} else if (-1 < num && num < 0) {  \n		return strNum.replace(/^-0\\./, \"-.\");  \n	}  \n	return strNum;  \n};  \n```  \n  \n我们还可以更进一步，彻底移除正则匹配。因为我们 100% 确定前置 0 在字符串中的位置，因此完全可以直接对字符串进行裁剪，而非借助正则表达式。  \n  \n```jsx  \nconst stringifyNumber = (number: number, precision: number) => {  \n	// ...snip  \n  \n	// remove zero whole from decimal number  \n	const strNum = number.toString();  \n	if (0 < num && num < 1) {  \n		// Plain string processing is all we need  \n		return strNum.slice(1);  \n	} else if (-1 < num && num < 0) {  \n		// Plain string processing is all we need  \n		return \"-\" + strNum.slice(2);  \n	}  \n	return strNum;  \n};  \n```  \n  \n由于 SVGO 的代码中已经有一个专门用于去除前置 0 的方法，所以我们可以直接复用他。这样一来，又节省了 0.9 秒。[Upstream PR](https://github.com/svg/svgo/pull/1717).  \n  \n# 内联函数，内敛缓存与递归  \n  \n一个叫 monkey 的函数仅凭名字就引起了我的兴趣。从性能分析中我们可以看到它在自身内部被多次调用，这几乎就可以确定这里使用了某种递归，而递归经常被用在遍历树状结构中。  \n只要在代码中涉及到便利操作，他就很有可能处于代码中的”热点“路径上。虽然这不适用于所有场景，但根据我的经历来看，这是一条相当可靠的经验法则。  \n  \n```jsx  \nfunction perItem(data, info, plugin, params, reverse) {  \n	function monkeys(items) {  \n		items.children = items.children.filter(function (item) {  \n			// reverse pass  \n			if (reverse && item.children) {  \n				monkeys(item);  \n			}  \n			// main filter  \n			let kept = true;  \n			if (plugin.active) {  \n				kept = plugin.fn(item, params, info) !== false;  \n			}  \n			// direct pass  \n			if (!reverse && item.children) {  \n				monkeys(item);  \n			}  \n			return kept;  \n		});  \n		return items;  \n	}  \n	return monkeys(data);  \n}  \n```  \n  \n这段代码中，有一个函数在其自身创建了另一个函数，且这个函数会调用自身。如果让我猜的话，这样写大概率是为了少敲一段代码，为了避免在递归调用时反复传递所有参数。但问题在于，在函数内部动态创建的函数，当外层函数被频繁调用时，很难被引擎有效地优化。  \n  \n```jsx  \nfunction perItem(items, info, plugin, params, reverse) {  \n	items.children = items.children.filter(function (item) {  \n		// reverse pass  \n		if (reverse && item.children) {  \n			perItem(item, info, plugin, params, reverse);  \n		}  \n		// main filter  \n		let kept = true;  \n		if (plugin.active) {  \n			kept = plugin.fn(item, params, info) !== false;  \n		}  \n		// direct pass  \n		if (!reverse && item.children) {  \n			perItem(item, info, plugin, params, reverse);  \n		}  \n		return kept;  \n	});  \n	return items;  \n}  \n```  \n  \n我们可以通过显式传递所有参数，来彻底移除这个内部函数，而不是像之前那样通过闭包来捕获变量。这一改动的单项影响并不算大，但累计下来，也节省了约 0.8 秒的时间。  \n  \n好在这一问题已经在最新的 3.0.0 主版本中得到了解决，只是整个生态迁移到新版本还需要一些时间。  \n  \n# 警惕 for…of 的转移带来的开销  \n  \n在 @vanilla-extract/css 中出现了一个几乎相同的问题， 在已发布的正式包中包含了下面这段代码。  \n  \n```jsx  \nclass ConditionalRuleset {  \n	getSortedRuleset() {  \n		//...  \n		var _loop = function _loop(query, dependents) {  \n			doSomething();  \n		};  \n  \n		for (var [query, dependents] of this.precedenceLookup.entries()) {  \n			_loop(query, dependents);  \n		}  \n		//...  \n	}  \n}  \n```  \n  \n这段函数有趣的地方在于，他并不存在于源代码中，在源代码中这里只是一个标准的 for…of 循环。  \n  \n```jsx  \nclass ConditionalRuleset {  \n	getSortedRuleset() {  \n		//...  \n		for (var [query, dependents] of this.precedenceLookup.entries()) {  \n			doSomething();  \n		}  \n		//...  \n	}  \n}  \n```  \n  \n我没能在 babel 或 typescript的 repl 中复现这个问题，但可以确认的是，这确实是由他们的构建流水线引入的。鉴于这看起来是对他们构建工具的一层通用抽象，我猜测还会有不少其他项目受到同样的影响。因此我目前只是在 node_modules 中对此包进行了本地修复，令人满意的是，构建时间缩短了 0.9 秒。  \n  \n# semver 中的奇妙案例  \n  \n关于这个问题，我不确实是不是我的配置有问题。但看上去每当 Babel 转译一个文件时，他都会重新读取完整 Babel 配置。  \n  \n![image.png](https://marvinh.dev/media/js-tools-babel-semver.png)  \n  \n在截图中很难看清楚，但有一个占用时间相当多的函数，来自于 semver 这个包，也就是同样在 npm cli 中使用的那个 semver 包。这就有点令人迷惑了，semver 和 Babel 有什么关系？我过了好一会儿才恍然大悟：他是用来解析 @babel/preset-env 中的 Browserslist 目标配置的。尽管 Browserslist 的配置看起来只有短短一条，但当其展开后，最终会变成大约 290 个独立版本。  \n  \n仅此一点还不是很让人担心，但是很容易让人忽略其使用各种校验函数时所带来的内存分配成本。这段流程在 babel 的代码中有些分散，但整体流程是将浏览器目标的版本号转换成 semver 字符串（例如将 10 转换为 10.0.0），然后进行校验。并且其中有些版本号是符合 semver 格式的。这些版本号，有时甚至是版本范围会彼此进行比较，直到找到我们所需要转译的最小公共特性集合。这种做法没有任何问题。  \n  \n之所以这里会出现性能问题，是因为 semver 版本是以字符串形式存储的，而不是已经解析的 semver 数据类型。这意味着每次调用 semver.valid(’1.2.3’)，都会新建一个 semver 实例且立即被销毁。同理当使用字符串进行 semver 版本号比较时：semver.lt(’1.2.3’,’9.8.7’)。这也是为什么在性能分析的调用轨迹中，semver 会如此显眼。  \n  \n通过在本地的 node_modules 中进行修复，构建时间有进一步缩短了约 4.7 秒。  \n  \n# 结论  \n  \n到这里后我就没有在继续深挖了。不过我相信，在许多流行的库中可以找到更多类似的细微的性能问题。今天我们主要关注的是构建工具，不过在 UI 组件或其他类型的库中，通常也同样存在这种可快速发现的性能问题。  \n  \n这些优化能让性能足以追上 Go 或 Rust 吗？基本上不行，但现有的 JavaScript 工具的性能确实可以比他们现在的表现更好更快。而本文所关注的内容，或多或少只是冰山一角。','2026-01-19 14:45:52.205','2026-01-19 14:45:52.205',0,0,0),(17,'cmkarwq5v0003b47kn18mszur','文章内容格式展示','# H1  \n## H2  \n### h3  \n#### h4  \n##### h5  \n正文  \n*斜体*  \n**加粗**  \n`inline code`  \n[链接](/)  \n```javascript  \nconst a = 123;  \nconsole.log(\'a\',a)  \n```  \n![图片](/myCat.jpg)  \n### 数学公式  \n$$E = mc^2$$  \n$$\\int_{-\\infty}^{\\infty} e^{-x^2} dx = \\sqrt{\\pi}$$  \n### 行内公式  \n文本中的变量 $x = 5$ 和函数 $f(x) = x^2 + 2x + 1$。','2026-01-22 03:18:38.662','2026-01-22 03:18:38.662',0,0,0),(33,'cmkarwq5v0003b47kn18mszur','模块解析 —— 加速 JavaScript 系统','📖 简明总结：无论你是在构建、测试还是进行 JavaScript 代码检查（linting），模块解析始终是所有操作的核心。尽管它在我们的工具链中占据核心地位，但过去很少有人专注于提升其速度。本文讨论的改进可以让相关工具的运行速度提高 **高达 30%**。  \n  \n在本系列的第一部分我们找到了一系列加速 JavaScript 工具中各类库的方法。虽然这些底层优化确实显著缩短了整体构建时间，但我在思考在工具中是否还有一些更根本性的环节可以改进 —— 关于JavaScript 中更常见的任务，如打包、测试和代码检查。  \n  \n于是在接下来的几天里，我收集了大约十几份来自我们行业中常用的任务和工具的 CPU 性能分析。经过一番检查，我发现了一个在每份分析中都会出现的重复模式，他对这些任务总时长的影响高达 30%。这一环节在我们的基础设施中极为关键且影响深远，值得单独写一篇博客来进行说明。  \n  \n这个关键的环节就是模块解析。在我查看的所有性能追踪中，它所消耗的总时间甚至超过了源代码解析的时间。  \n  \n# 捕获调用栈的开销  \n  \n这一切的起因是我注意到那些性能追踪中，耗时最高的环节是 `captureLargerStackTrace`  —— 这是一个 Node 的内部函数，用于将调用栈附加到 `Error` 对象上。鉴于这两个任务都成功完成，且没有抛出任何错误，这看起来有些不正常。  \n  \n![Result table in speedscope showing captureLargerStack traces taking up to 29% time in various traces](https://marvinh.dev/media/js-tools-2-trace.png)  \n  \n在浏览了性能分析中大量的调用记录后，一个更清晰的情况显现了出来。几乎所有的错误创建都由 `fs.statSync()` 调用，并且这个函数又是在另一个叫做 `isFIle` 的函数内部调用的。文档中提到 `fs.statSync` 基本相当于 POSIX 的 `fstat` 命令，用于检查磁盘上的路径是否存在，以及该路径是文件还是目录。基于这一点可得，我们只有在文件不存在或无权限访问等类似的情况下才会触发这个错误。所以是时候去看看 `isFile` 的源码了。  \n  \n```jsx  \nfunction isFile(file) {  \n	try {  \n		const stat = fs.statSync(file);  \n		return stat.isFile() || stat.isFIFO();  \n	} catch (err) {  \n		if (err.code === \"ENOENT\" || err.code === \"ENOTDIR\") {  \n			return false;  \n		}  \n		throw err;  \n	}  \n}  \n```  \n  \n乍一看，这个函数似乎人畜无害，但他却频繁出现在性能追踪中。值得注意的是，这里我们忽略了指定的错误并直接返回 false，而不是继续将错误抛出。无论是 ENOENT 还是 ENOTDIR 错误码，都表示路径在磁盘上不存在。或许我们看到的性能开销就是这里产生的？毕竟，这些错误被立马捕获并忽略了。为了验证这个猜想，我将所有 try/catch 代码块捕获的错误都记录了下来，结果不出所料：这里每个被抛出的错误，错误码不是 ENOENT 就是 ENOTDIR。  \n  \n在查阅 node 中关于 `fs.statSync` 的文档后可以发现，它支持传入一个 `throwIfNoEntry` 选项，用于在文件系统中不存在对应文件时不要抛出错误。这种情况下他会返回 `undefined` 作为替代。  \n  \n```jsx  \nfunction isFile(file) {  \n	const stat = fs.statSync(file, { throwIfNoEntry: false });  \n	return stat !== undefined && (stat.isFile() || stat.isFIFO());  \n}  \n```  \n  \n在使用这个参数后，我们可以去掉这个 catch 代码块中的 if 判断，因此这个 tyr/catch 也没有存在的意义了，这使得我们可以进一步简化这个函数。  \n  \n仅这一项改动，就是我们的项目在代码检查阶段的耗时减少了 7%，令人惊喜的是，在测试阶段也同样因为这个改动而得到了近似程度的提升。  \n  \n# 文件系统的高额性能开销  \n  \n在消除了性能追踪中关于函数的性能开销后，我仍觉得问题仍未止步于此。毕竟，在一段持续几分钟的性能追踪中，抛出几个错误不应该会造成如此明显的影响。于是，我在这个函数中添加了一个计数器，来查看它的调用频率。结果很明显，他被调用了近一万五千次，差不多是这个项目中文件数量的十倍。看起来这里有着很大的优化空间。  \n  \n## 模块化还是不模块化，这是个问题  \n  \n默认情况下，一个工具要识别三种模块说明符（specifiers）  \n  \n- 相对路径模块导入: `./foo` , `../bar/boof`  \n- 绝对路径模块导入: `/foo` , `/foo/bar/bob`  \n- 包导入: `foo` , `@foo/bar`  \n  \n从性能的角度来看，最值得关注的是第三种。这种即不由点 `.` 或斜杠 `/` 开头的直接导入的标识符，是基本只用于导入 npm 包的特殊导入方式。这种解析算饭在 node 的文档中有详细的说明。简单来说，他会尝试解析包名，然后会沿着文件目录向上遍历，查找是否存在包含该模块的特殊   \n\n`node_modules` 目录。让我们通过示例来说明这一过程。  \n  \n假设我们有一个文件位于 `/Users/marvinh/my-project/src/features/DetailPage/components/Layout/index.js`,她想要导入一个模块 `foo` .那么模块解析算法会依次检查一下位置。  \n  \n- `/Users/marvinh/my-project/src/features/DetailPage/components/Layout/node_modules/foo/`  \n- `/Users/marvinh/my-project/src/features/DetailPage/components/node_modules/foo/`  \n- `/Users/marvinh/my-project/src/features/DetailPage/node_modules/foo/`  \n- `/Users/marvinh/my-project/src/features/node_modules/foo/`  \n- `/Users/marvinh/my-project/src/node_modules/foo/`  \n- `/Users/marvinh/my-project/node_modules/foo/`  \n- `/Users/marvinh/node_modules/foo/`  \n- `/Users/node_modules/foo/`  \n  \n这意味着需要进行大量的文件系统调用。简而言之，在解析过程中的每层目录都会检查是否存在模块目录，这意味着检查次数和文件所在的目录层级数量直接相关。问题在于，这会在每一个导入了 `foo` 模块的文件中重复进行。如果有另一个在不同位置的文件同样导入了 `foo` 模块，那么解析器将同样沿着整个目录树向上遍历，直到找到包含模块的 `node_modules` 目录为止。因此，对已解析过的模块进行缓存将会带来显著的性能提升。  \n  \n而情况更有趣的是，许多项目会使用路径映射别名来减少输入量，从而在整个项目中统一使用导入说明符，避免出现大量 `../../../`。这种做法通常通过 TypeScript 的 `paths` 编译选项或打包工具中的 `resolve alias` 来实现。但问题在于，这些别名通常很难与包导入区分开来。例如，如果我为位于 `/Users/marvinh/my-project/src/features/` 的 `features` 目录添加了路径映射，我就可以使用 `import {...} from \"features/DetailPage\"` 这个声明来导入他，同样，每个工具都可以识别这个别名。  \n  \n但是如果工具不支持呢？由于没有一个统一的模块解析包被所有的 JavaScript 工具所使用，所以目前有多个各自独立的解析实现，他们对此功能的支持程度也各不相同。在我的案例中，项目中使用了大量的路径映射，同时包含了一个不识别 typescript `tsconfig.json` 中路径映射代码的代码检查插件。那么自然这个插件就会将 `feature/DetailPage` 看做是一个 node 模块，并通过向上遍历的方式来寻找这个模块，结果没有找到，并抛出了错误。  \n  \n# 对所有内容进行缓存  \n  \n接下来，我改进了日志记录，来查看该函数被调用时使用了多少不同的文件路径，以及是否返回了相同的结果。记过显示只有约 2.5k 次对 `isFile` 的调用使用了唯一的路径，并且传入的文件参数和返回结果基本呈现出一一对应的关系。虽然这一数量仍然超过了项目文件数量，但远低于之前的一万五千次调用总数。那么，如果我们在函数外层添加一个缓存来避免每次都访问文件系统，结果会如何呢？  \n  \n```jsx  \nconst cache = new Map();  \n  \nfunction resolve(file) {  \n	const cached = cache.get(file);  \n	if (cached !== undefined) return cached;  \n  \n	// ...existing resolution logic here  \n  \n	const resolved = isFile(file);  \n	cache.set(file, resolved);  \n	return file;  \n}  \n```  \n  \n引入缓存后，代码检查的耗时又加快了 15%。真不错！不过缓存的风险在于他可能会过期，所以有必要在某个时刻对缓存进行失效处理。为了保险起见，我最终选择了一种更稳妥的方式：在使用缓存前，先检查文件是否仍然存在。考虑到工具总是在 watch 模式下运行，所以这种方法并不罕见 —— 这种模式下，工具通常会缓存所有数据，并只对已修改的文件进行失效处理。  \n  \n```jsx  \nconst cache = new Map();  \n  \nfunction resolve(file) {  \n	const cached = cache.get(file);  \n  \n	// A bit conservative: Check if the cached file still exists on disk to avoid  \n	// stale caches in watch mode where a file could be moved or be renamed.  \n	if (cached !== undefined && isFile(file)) {  \n		return cached;  \n	}  \n  \n	// ...existing resolution logic here  \n	for (const ext of extensions) {  \n		const filePath = file + ext;  \n  \n		if (isFile(filePath)) {  \n			cache.set(file, filePath);  \n			return filePath;  \n		}  \n	}  \n  \n	throw new Error(`Could not resolve ${file}`);  \n}  \n```  \n  \n老实说，当我将之前的逻辑调整为即使命中了缓存，也访问文件系统进行检查之后，我以为他会抵消添加缓存后带来的性能提升。但当我观察了记录的次数后，我发现他对于之前的提升只影响了 0.05%. 这几乎可以忽略不计了，但是额外的文件系统调用不应该产生更大的影响吗？  \n  \n# 文件扩展名的”猜谜游戏”  \n  \nJavaScript 模块的问题在于，这门语言一开始并没有内置模块系统。当 node.js 出现了，他推广了 CommonJS 模块系统。这个系统有几个“有趣”的特性，例如可以省略被加载文件的扩展名。例如当你类似 `require(\"/foo)\"` 的语句时，他会自动添加上 `.js` 扩展名并尝试读取 `./foo.js` 文件。如果文件不存在，他会接着检查 json 文件 `./foo.json` ,如果他也不存在，则会检查 `./foo/index.js` 。  \n  \n这里其实主要处理的是歧义问题，工具必须准确判断 `./foo` 应该解析的是哪个文件。因为无法事先确定文件在哪里，所以未导致大量的无用的文件系统调用。工具必须注意尝试每种可能的组合，直到找到匹配的为止。考虑到当前如今可能的扩展名的数量，这个问题就更严重了。工具通常要维护一个用于检查的所有潜在扩展名的数组。在包含 TypeScript 的前提下，一个传统前端项目可能包含的扩展名数组如下所示：  \n  \n```jsx  \nconst extensions = [  \n	\".js\",  \n	\".jsx\",  \n	\".cjs\",  \n	\".mjs\",  \n	\".ts\",  \n	\".tsx\",  \n	\".mts\",  \n	\".cts\",  \n];  \n```  \n  \n这意味着工具需要检查八种潜在的扩展名。而且 这并不是全部，在考虑到可能使用同样扩展名的 index 文件，这个列表基本上要再翻一倍。这意味着我们的工具别无选择，只能循环遍历扩展名列表，直到我们找到磁盘上存在的文件。当我们尝试解析实际为 `./foo.ts` 的 `./foo` 文件时，我们需要检查：  \n  \n1. `foo.js` -> doesn’t exist  \n2. `foo.jsx` -> doesn’t exist  \n3. `foo.cjs` -> doesn’t exist  \n4. `foo.mjs` -> doesn’t exist  \n5. `foo.ts` -> bingo!  \n  \n这导致了四次不必要的文件系统调用。当然，你可以调整扩展名的顺序，把项目中最常用的扩展名放到数组的开头。这能提高尽早找到正确扩展名的概率，单着并不能完全解决问题。  \n  \n在 ES2015 规范的中，提出了一个新的模块系统。尽管当时还没有完全确定所有的细节，但语法已经确定下来了。import 语句凭借着其在工具链方面比 CommonJS 有更多优势，很快便占据了主导地位。由于其静态特性，它为更多的工具改进功能提供的空间，其中最著名的就是 tree-shaking —— 可以轻松检测那些未被使用的模块，甚至是模块中未被使用的函数，从而优化生产环境构建。自然，所有人都开始使用新的 import 语法。  \n  \n不过仍然有个问题：由于当时只有语法被确定下来，而实际的模块加载或解析方式并不明确。为了弥补这一空白，工具沿用了 CommonJS 现存的语义。这样对代码移植来说非常有利，因为大部分改动只需要进行语法上的改动，并且这些改动可以通过代码转换工具自动完成。从推广的角度来看，这无疑非常有效。但这意味着我们同样继承了之前的扩展名“猜谜游戏”。  \n  \n关于模块导入和解析的细节在几年后最终被确定了下来，并通过强制制定扩展名的方式修复了这个问题。  \n  \n```jsx  \n// Invalid ESM, missing extension in import specifier  \nimport { doSomething } from \"./foo\";  \n  \n// Valid ESM  \nimport { doSomething } from \"./foo.js\";  \n```  \n  \n通过消除这一歧义，并始终强制要求添加扩展名，我们避免了所有这类问题。工具的运行速度也提高了。但要让整个生态系统采纳这一做法仍需要一段时间，甚至不会完全实现。因为很多工具已经适应了这种歧义处理方式。  \n  \n# 下一步该怎么做？  \n  \n在整个调查过程中，我有些惊讶地发现，模块解析的优化空间竟然如此之大，尤其考虑到它在我们的工具链中占据如此核心的位置。本文中描述的几项改动就使代码检查耗时 降低了 30%！  \n  \n我们这里所做的几项优化措施并非 JavaScript 所独有。在其他编程语言的工具链中同样可以找到类似的优化方法。在模块解析中，主要有四个要点：  \n  \n1. 尽量避免频繁访问文件系统  \n2. 尽可能使用缓存，以减少对文件系统的调用  \n3. 使用 `fs.stat` 或 `fs.statSync` 时，务必设置 `throwIfNoEntry: false`  \n4. 尽量限制向上遍历目录的次数  \n  \n我们的工具链运行缓慢的问题并非由于 JavaScript 语言本身引起，而是因为相关环节没有得到完全的优化。由于没有一个统一的模块解析标准包，JavaScript 生态系统的碎片化也无法为帮助其改善这一点。正相反，存在了多个仅支持各自功能的子集。但这并不奇怪，因为多年来需要支持的功能列表不断增长，而且截至本文撰写之时，还没有任何一个库能够支持所有这些功能。如果有一个被所有人使用的统一库，就能让这一问题得到彻底解决，从而大大简化优化工作。','2026-01-23 03:57:52.724','2026-01-23 09:57:27.925',0,0,0),(34,'cmkarwq5v0003b47kn18mszur','TypeScript 知识点总结速查','# interface 和 types  \n  \n## 共同点  \n  \n二者都可用于描述对象。  \n  \n## 区别  \n  \n### 扩展方式：  \n  \ninterface：用 `extends` 进行扩展  \n  \ntype：主要用 `&` 进行扩展  \n  \n```tsx  \n// interface   \ninterface User { name: string };  \ninterface Admin extends User { role: \"admin\" };  \n// type  \ntype TUser = { name: string };  \ntype TAdmin = TUser & { role: \"admin\" };  \n```  \n  \n### 联合类型  \n  \ninterface 声明方式基本是固定的，只能用来描述 “对象” 的结构  \n  \ntype 是 **类型别名**，有多种声明方式用于不同的类型，更全能  \n  \n```tsx  \n// 联合类型 Union  \ntype Id = string | number;  \nconst idStr: Id = \"a\";  // √  \nconst idNum: Id = 123;  // √  \nconst idBoolean:Id = false; // × —— 类型必须是 string 或者 number  \n  \n// 元组类型 tuple  \ntype StringNumberPair = [string, number];  \nconst strNum: StringNumberPair = [\"abc\", 123]; // √  \nconst numStr: StringNumberPair = [123,\"abc\"];  // × —— 数组中第一项元素类型必须为 string, 且第二项元素类型必须为 number  \n  \n// 函数 function  \ntype Fn = (x:number) => string;  \nconst foo:Fn = (a:number) => { return \"123\" };  // √  \nconst bar:Fn = (a:string) => { return 123 };    // × —— 参数类型必须是 number, 且返回值类型必须是 string  \n  \n```  \n  \n## 联合声明  \n  \ninterface 可以不同文件/位置重复声明，这些重复声明会合并成联合声明。多用于给全局对象或第三方库做扩展时使用。  \n  \ntype 不允许重复声明  \n  \n```tsx  \ninterface Global { app?: {version: string }}  \n// 再次声明 Global   \ninterface Global { logger?: (msg: string) => void }  \nconst a: Global = {};  \nconst myappVersion = a.app?.version; // √  \na.logger?.(\"success\");  // √  \n  \ntype TypeA = string;  \ntype TypeA = number; // × —— 标识 TypeA 重复  \n```  \n  \n## any/unknown/never  \n  \n## any  \n  \n含义：指定这个值可以使任意类型，给他无论给他传递什么类型的值都不会有问题。相当于告诉 TypeScript 不要对这个变量进行检查。  \n  \n带来的问题：  \n  \n1. TypeScript 编译通过不代表运行时没有问题，使用 any 会将编译时就能暴露出来的问题带到运行时环境。  \n  \n```tsx  \nlet x: any = 1;  \nx.foo(); // √ —— TypeScript 编译通过. 运行时: ×, x 上没有 foo 方法  \nx(); // √ —— TypeScript 编译通过. 运行时: ×, x is not a function  \nx.bar = 100; // √ —— TypeScript 编译通过. 运行时: ×, 不会有报错提示, 但获取 x.bar 永远都是 undefine  \nx = [\"hello\"]; // √ —— TypeScript 编译通过. 运行时不会报错, 但在大部分业务场景下, 类型不同会引发非预期的问题。  \nconst n: string = x; // √ —— TypeScript 编译通过.  \n```  \n  \n1. any 会污染类型推断，及一旦一个指定类型的值被 any 类型影响，后续关于这个值的类型推断都不一定可信. 例如我声明一个 obj 为 any 类型 —— `const obj: any = { a: 1 };` 那么之后在编辑器中, 在输入 `obj.` 后不会有属性或方法提示, 即使此时 obj 是包含 a 这个属性的。同理, 在输入 `obj.a.` 的时候，也不会有任何方法提示，即使此时 a 是 number 类型，其本身至少是包含 `.toString()`/ `.valueOf()` 等方法的。  \n  \n应用场景  \n  \nany 一般用于接入第三方无类型库或需要快速产出原型等场景下。不过还是建议尽快调整成 `unknow` 或具体类型。  \n  \n<aside>  \n💡  \n  \n在严格的业务场景下均不建议使用 any，而且通常会将此规则其加入 tslint 或者 eslint。  \n  \n</aside>  \n  \n## unknow  \n  \n含义：用于声明值的类型未知，不能直接使用，必须先做类型守卫或断言。  \n  \n```tsx  \nconst a: unknown = JSON.parse(\"{foo:1}\");  \na.foo // × —— a 的类型为“未知”  \nif (a && typeof a === \"object\" && \"foo\" in a) {  \n  // 添加类型判断后, 才可使用  \n  console.log( a.foo );  // √ 打印 1  \n}  \n```  \n  \n使用场景  \n  \n- 外部输入：接口返回，localStorage，postMessage 等  \n- `JSON.parse`  \n- `catch(e: unknown)` catch 中的错误对象现在在  TypeScript 中一般为 `unkonwn`  \n  \n## never  \n  \n含义：这个值永远不会存在 / 某个函数永不返回（和 返回 void 有本质的区别，详见下文）/ 永远无法访问的代码  \n  \n```tsx  \n// 函数只可能 throw, 不 return  \nfunction fn(): never {  \n  throw \"err\";  \n}  \n// 函数内部无限循环,永不结束  \nfunction fn(): never {  \n  while (true) {}  \n}  \n// 永远无法访问的代码  \nfunction fn(x: \"number\" | \"string\") {  \n  if (typeof x === \"number\") {  \n    return 123;  \n  } else if (typeof x === \"string\") {  \n    return \"123\";  \n  } else {  \n    const n: never = x;  // n 的类型就是 never, 因为正常情况下, 这里永远无法访问到。  \n  }  \n}  \n```  \n  \n使用场景：  \n  \n主要用于在 TypeScript 下，在编译期间对一些期望永远无法访问的代码部分做兜里处理。  \n  \n```tsx  \ntype A = \"a\" | \"b\";  \n  \nfunction assertNever(x: never): never {  \n  throw new Error(\"Unexpected: \" + x);  \n}  \n  \nfunction fn(prop: a) {  \n  switch (prop) {  \n    case \"a\":  \n      return 1;  \n    case \"b\":  \n      return 2;  \n    default:  \n      return assertNever(prop);  \n  }  \n}  \n```  \n  \n上面的函数中，default 分支中的写法，如果我希望能在编译时让 TypeScript 对 switch 分支做 ”穷尽检查”，当走到 default 分支时， `prop` 必须是 `never` ，即前面的分支已经覆盖了所有的可能。  \n  \n所有如果后来 type A 增加了新的类型 ”c”，但没有在函数中添加上对 `case \"c\"` 分支的处理时，在编译阶段 TypeScript 就会报错，因为此时 default 分支里面的 `prop` 是 `\"c\"` 而不是 `never` 了。  \n  \n相当于在这里做了一个声明：**这里永远不可达，除非前面代码出现了漏洞。**  \n  \n### 函数返回 `never` 和 `void` 的区别  \n  \n`void` 表示有返回，但没有返回值，或者返回值不重要。函数是 “正常” 运行到 `return` 结束的，但不需要关心 `return` 的值（通常为 undefined）。  \n  \n`never` 表示函数永不结束，如死循环或不会 “正常” 结束，如 `throw new Error(\"error\")` 。函数不会走到 `return` 这一步。  \n  \n## Parameters<T>/ReturnType<T>  \n  \n### Parameters<T>  \n  \n含义：如果 `T` 是函数类型，就把它的参数列表推断成一个 tuple `P` 并返回。  \n  \n```tsx  \nfunction fn(a: string, b: number, c?: boolean) {  \n  return c ? a : b;  \n}  \n  \ntype P = Parameters<typeof fn>;  \n// 相当于 type P = [a: string, b: number, c?: boolean | undefined]  \n```  \n  \n### ReturnType<T>  \n  \n含义：如果 `T` 是函数类型，就把它的参数列表推断成一个 tuple `P` 并返回。  \n  \n```tsx  \nfunction fn(a: number, b: string) {  \n  return { code: a, msg: b };  \n}  \n  \ntype R = ReturnType<typeof fn>;  \n// 相当于 type R = { code: number; msg: string; }  \n```  \n  \n## 需要注意的点  \n  \n1. 对有重载的函数，`Parameters<typeof fn>` / `ReturnType<typeof fn>` 通常会取到最后一个签名（实现签名）或某种合并结果，不一定是你期望的“所有重载”。这种场景建议为每个重载单独定义类型或用接口建模。  \n  \n```tsx  \n// 重载声明  \nfunction parse(input: string): number;  \nfunction parse(input: number): string;  \n  \n// 重载函数实现  \nfunction parse(input: string | number) {  \n  return typeof input === \"string\" ? input.length : String(input);  \n}  \n  \ntype P = Parameters<typeof parse>;  \ntype R = ReturnType<typeof parse>;  \n  \n// 期望是:  \n// P 是 [string] | [number]  \n// R 是 number | string（并且能跟参数关联）  \n//  \n// 实际上通常会变成:  \n// P = [input: string | number]  \n// R = string | number  \n```  \n  \n1. `ReturnType` 在异步函数中直接拿到的是 Promise，如果要拿到实际返回值，需要添加 `Awaited`   \n\n```tsx  \nasync function fn() {  \n  return \"123\";  \n}  \ntype R = ReturnType<typeof fn>;  \n// type R = Promise<string>  // Promise  \n  \ntype RealR = Awaited<ReturnType<typeof fn>>;  \n// type RealR = string  // string  \n```  \n  \n1. `Parameters` 只适用于函数类型  \n  \n`Parameters` 传非函数会报约束错误，或得到 never/any.  \n  \n```tsx  \nconst a = \"123\";  \n  \ntype A = Parameters<typeof a>;  \n// × —— 类型 string 不满足约束“(...args: any) => any”。  \n```  \n  \n### 使用场景  \n  \n1. 高阶函数/装饰器  \n  \n```tsx  \n// 希望实现一个高阶函数 wrap(fn)，让它的入参类型和出参类型与 fn 一致。  \nfunction withLog<T extends (...args: Parameters<T>) => ReturnType<T>>(fn: T) {  \n  return (...args: Parameters<T>): ReturnType<T> => {  \n    console.log(\"call with\", args);  \n    return fn(...args);  \n  };  \n}  \n  \nconst a = (num: number) => num + 1;  \nconst logA = withLog(a);  \ntype TypeA = typeof a; // (num: number) => number  \ntype TypeLogA = typeof logA; // (num: number) => number 与 TypeA 一致  \n```  \n  \n1. 把现有函数的签名复用到别处（避免重复写类型）  \n  \n```tsx  \n// 有 service.fetchUser, 期望在 mock、测试、或 adapter 里保持同签名。  \ntypeFetchUser =typeof fetchUser;  \ntypeFetchUserArgs =Parameters<FetchUser>;  \ntypeFetchUserRes =ReturnType<FetchUser>;  \n```  \n  \n1. 事件/回调类型对齐（React props / SDK 回调  \n  \n```tsx  \n// 表单组件 onSubmit 的参数类型复用到校验器、提交器  \ntypeOnSubmit =(values: { name:string }) =>Promise<void>;  \n  \ntypeOnSubmitArgs =Parameters<OnSubmit>[0];// { name: string }  \ntypeOnSubmitReturn =ReturnType<OnSubmit>;// Promise<void>  \n```  \n  \n类型安全的“转发调用”（proxy / RPC / client）  \n  \n```tsx  \ntypeApi = {  \ngetUser:(id:string) =>Promise<{id:string }>;  \nlistUsers:(q: { page:number }) =>Promise<{items:any[] }>;  \n};  \n  \nfunction call<Kextends keyofApi>(  \nkey: K,  \n  ...args:Parameters<Api[K]>  \n):ReturnType<Api[K]> {  \n// transport.call(key, args)...  \nthrownewError(\"not implemented\");  \n}  \n```','2026-01-27 09:51:53.958','2026-01-27 09:51:53.958',0,0,0);
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogfavorite`
--

DROP TABLE IF EXISTS `blogfavorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogfavorite` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blogId` int NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `BlogFavorite_blogId_userId_key` (`blogId`,`userId`),
  KEY `BlogFavorite_userId_idx` (`userId`),
  KEY `BlogFavorite_blogId_idx` (`blogId`),
  CONSTRAINT `BlogFavorite_blogId_fkey` FOREIGN KEY (`blogId`) REFERENCES `blog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `BlogFavorite_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogfavorite`
--

LOCK TABLES `blogfavorite` WRITE;
/*!40000 ALTER TABLE `blogfavorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogfavorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bloglike`
--

DROP TABLE IF EXISTS `bloglike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bloglike` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blogId` int NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `BlogLike_blogId_userId_key` (`blogId`,`userId`),
  KEY `BlogLike_userId_idx` (`userId`),
  KEY `BlogLike_blogId_idx` (`blogId`),
  CONSTRAINT `BlogLike_blogId_fkey` FOREIGN KEY (`blogId`) REFERENCES `blog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `BlogLike_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bloglike`
--

LOCK TABLES `bloglike` WRITE;
/*!40000 ALTER TABLE `bloglike` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloglike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dailystat`
--

DROP TABLE IF EXISTS `dailystat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dailystat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime(3) NOT NULL,
  `typingCount` int NOT NULL DEFAULT '0',
  `stepCount` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DailyStat_date_key` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailystat`
--

LOCK TABLES `dailystat` WRITE;
/*!40000 ALTER TABLE `dailystat` DISABLE KEYS */;
INSERT INTO `dailystat` VALUES (5,'2026-01-21 00:00:00.000',5000,10000,'2026-01-21 02:41:33.935','2026-01-21 02:44:58.901'),(6,'2026-01-25 00:00:00.000',5000,10000,'2026-01-21 07:42:41.392','2026-01-21 07:42:41.392'),(7,'2026-01-26 00:00:00.000',5000,10000,'2026-01-21 08:02:19.715','2026-01-22 12:30:30.611'),(8,'2026-01-22 00:00:00.000',5000,10000,'2026-01-22 12:34:42.023','2026-01-22 12:34:42.023');
/*!40000 ALTER TABLE `dailystat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise`
--

DROP TABLE IF EXISTS `exercise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Exercise_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise`
--

LOCK TABLES `exercise` WRITE;
/*!40000 ALTER TABLE `exercise` DISABLE KEYS */;
INSERT INTO `exercise` VALUES (24,'俯卧撑'),(17,'全身锻练');
/*!40000 ALTER TABLE `exercise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sessionToken` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_sessionToken_key` (`sessionToken`),
  KEY `sessions_userId_fkey` (`userId`),
  CONSTRAINT `sessions_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tag_userId_content_key` (`userId`,`content`),
  CONSTRAINT `Tag_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (13,'Todo','oklch(71.8% 0.202 349.761)','2025-12-26 07:06:13.628','2026-01-25 08:43:37.359','cmkarwq5v0003b47kn18mszur'),(14,'代码','','2025-12-26 07:06:13.628','2026-01-15 11:46:19.228','cmkarwq5v0003b47kn18mszur'),(15,'Tag','oklch(71.8% 0.202 349.761)','2025-12-26 13:54:39.948','2026-01-15 11:52:31.863','cmkarwq5v0003b47kn18mszur'),(16,'Blog','oklch(64.5% 0.246 16.439)','2025-12-26 13:54:39.946','2026-01-25 12:24:17.934','cmkarwq5v0003b47kn18mszur'),(19,'设计','','2025-12-26 15:27:39.947','2025-12-26 15:27:39.947','cmkarwq5v0003b47kn18mszur'),(20,'页面','oklch(78.9% 0.154 211.53)','2025-12-26 15:28:03.635','2026-01-22 12:36:32.519','cmkarwq5v0003b47kn18mszur'),(21,'日历','oklch(57.7% 0.245 27.325)','2025-12-27 07:02:51.587','2026-01-18 09:24:10.624','cmkarwq5v0003b47kn18mszur'),(22,'布局','oklch(45.5% 0.188 13.697)','2025-12-30 08:08:48.090','2026-01-28 12:54:24.411','cmkarwq5v0003b47kn18mszur'),(23,'组件','oklch(58.6% 0.253 17.585)','2025-12-31 04:54:18.398','2026-01-23 13:10:14.330','cmkarwq5v0003b47kn18mszur'),(24,'鉴权','oklch(71.5% 0.143 215.221)','2026-01-13 02:03:04.062','2026-01-13 02:14:51.384','cmkarwq5v0003b47kn18mszur'),(25,'api','oklch(79.2% 0.209 151.711)','2026-01-13 02:06:12.697','2026-01-13 02:06:12.697','cmkarwq5v0003b47kn18mszur'),(26,'博客','oklch(51.1% 0.262 276.966)','2026-01-13 02:08:15.652','2026-01-13 02:08:15.652','cmkarwq5v0003b47kn18mszur'),(27,'时间线','oklch(76.8% 0.233 130.85)','2026-01-13 02:31:45.156','2026-01-14 13:14:00.914','cmkarwq5v0003b47kn18mszur'),(28,'add new tag','oklch(29.1% 0.149 302.717)','2026-01-13 03:04:55.166','2026-01-14 13:46:33.278','cmkarwq5v0003b47kn18mszur'),(29,'进度条','oklch(58.8% 0.158 241.966)','2026-01-13 10:11:19.365','2026-01-14 13:14:00.911','cmkarwq5v0003b47kn18mszur'),(36,'评论','oklch(50.8% 0.118 165.612)','2026-01-15 01:42:39.495','2026-01-15 01:42:39.495','cmkarwq5v0003b47kn18mszur'),(37,'优化','oklch(64.8% 0.2 131.684)','2026-01-15 11:50:48.251','2026-01-22 00:22:33.796','cmkarwq5v0003b47kn18mszur'),(38,'公司','oklch(57.7% 0.245 27.325)','2026-01-17 03:36:59.478','2026-01-17 03:36:59.478','cmkarwq5v0003b47kn18mszur'),(39,'弹窗','oklch(55.8% 0.288 302.321)','2026-01-17 07:39:27.021','2026-01-23 12:13:57.535','cmkarwq5v0003b47kn18mszur'),(40,'番茄时钟','oklch(52.5% 0.223 3.958)','2026-01-17 13:29:45.058','2026-01-17 13:29:45.058','cmkarwq5v0003b47kn18mszur'),(41,'Contact','oklch(68.5% 0.169 237.323)','2026-01-18 02:52:38.408','2026-01-18 02:52:38.408','cmkarwq5v0003b47kn18mszur'),(42,'首页','oklch(57.7% 0.245 27.325)','2026-01-18 02:56:29.698','2026-01-18 02:56:29.698','cmkarwq5v0003b47kn18mszur'),(43,'天气','oklch(70.4% 0.14 182.503)','2026-01-18 09:23:36.883','2026-01-18 09:23:36.883','cmkarwq5v0003b47kn18mszur'),(44,'译文','oklch(57.7% 0.245 27.325)','2026-01-19 14:45:52.157','2026-01-23 04:06:47.319','cmkarwq5v0003b47kn18mszur'),(45,'性能优化','oklch(64.8% 0.2 131.684)','2026-01-19 14:45:52.156','2026-01-23 04:06:47.319','cmkarwq5v0003b47kn18mszur'),(46,'每日状态','oklch(63.7% 0.237 25.331)','2026-01-21 02:53:39.739','2026-01-21 14:02:42.080','cmkarwq5v0003b47kn18mszur'),(47,'每周状态','oklch(50.5% 0.213 27.518)','2026-01-21 02:54:25.862','2026-01-22 12:35:56.546','cmkarwq5v0003b47kn18mszur'),(48,'状态记录','oklch(44.8% 0.119 151.328)','2026-01-21 14:02:42.079','2026-01-22 12:36:32.519','cmkarwq5v0003b47kn18mszur'),(49,'示例','oklch(60.6% 0.25 292.717)','2026-01-22 03:18:38.609','2026-01-22 03:18:38.609','cmkarwq5v0003b47kn18mszur'),(50,'主题','oklch(59.1% 0.293 322.896)','2026-01-23 06:16:52.920','2026-01-23 13:10:39.627','cmkarwq5v0003b47kn18mszur'),(51,'CI','oklch(54.6% 0.245 262.881)','2026-01-23 10:18:47.214','2026-01-23 14:18:09.722','cmkarwq5v0003b47kn18mszur'),(52,'CD','oklch(51.1% 0.262 276.966)','2026-01-23 10:18:47.214','2026-01-23 14:18:09.723','cmkarwq5v0003b47kn18mszur'),(53,'权限','oklch(57.7% 0.245 27.325)','2026-01-25 08:29:16.966','2026-01-25 12:24:17.933','cmkarwq5v0003b47kn18mszur'),(55,'接口','oklch(54.6% 0.245 262.881)','2026-01-25 08:29:16.965','2026-01-25 12:24:17.933','cmkarwq5v0003b47kn18mszur'),(58,'超级时间线','oklch(66.7% 0.295 322.15)','2026-01-26 01:13:01.962','2026-01-28 12:54:24.410','cmkarwq5v0003b47kn18mszur'),(59,'知识点','oklch(58.6% 0.253 17.585)','2026-01-27 09:51:53.917','2026-01-27 11:45:03.637','cmkarwq5v0003b47kn18mszur'),(60,'TypeScript','oklch(68.5% 0.169 237.323)','2026-01-27 09:51:53.916','2026-01-27 11:43:28.911','cmkarwq5v0003b47kn18mszur'),(61,'React','oklch(77.7% 0.152 181.912)','2026-01-27 11:44:13.592','2026-01-27 11:44:13.592','cmkarwq5v0003b47kn18mszur'),(62,'工程化','oklch(68.1% 0.162 75.834)','2026-01-27 11:45:03.636','2026-01-27 11:45:03.636','cmkarwq5v0003b47kn18mszur'),(63,'工作','oklch(57.7% 0.245 27.325)','2026-01-28 12:55:05.569','2026-01-28 12:55:39.275','cmkarwq5v0003b47kn18mszur'),(64,'面试','oklch(69.6% 0.17 162.48)','2026-01-28 12:55:05.569','2026-01-28 12:55:39.275','cmkarwq5v0003b47kn18mszur');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagsonblogs`
--

DROP TABLE IF EXISTS `tagsonblogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagsonblogs` (
  `blogId` int NOT NULL,
  `tagId` int NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `assignedBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`blogId`,`tagId`),
  KEY `TagsOnBlogs_tagId_fkey` (`tagId`),
  CONSTRAINT `TagsOnBlogs_blogId_fkey` FOREIGN KEY (`blogId`) REFERENCES `blog` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TagsOnBlogs_tagId_fkey` FOREIGN KEY (`tagId`) REFERENCES `tag` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagsonblogs`
--

LOCK TABLES `tagsonblogs` WRITE;
/*!40000 ALTER TABLE `tagsonblogs` DISABLE KEYS */;
INSERT INTO `tagsonblogs` VALUES (16,44,'2026-01-19 14:45:52.194','cmkarwq5v0003b47kn18mszur'),(16,45,'2026-01-19 14:45:52.194','cmkarwq5v0003b47kn18mszur'),(33,44,'2026-01-23 04:06:47.331','cmkarwq5v0003b47kn18mszur'),(33,45,'2026-01-23 04:06:47.331','cmkarwq5v0003b47kn18mszur'),(34,59,'2026-01-27 09:51:53.946','cmkarwq5v0003b47kn18mszur'),(34,60,'2026-01-27 09:51:53.946','cmkarwq5v0003b47kn18mszur');
/*!40000 ALTER TABLE `tagsonblogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagsontodos`
--

DROP TABLE IF EXISTS `tagsontodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagsontodos` (
  `todoId` int NOT NULL,
  `tagId` int NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `assignedBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`todoId`,`tagId`),
  KEY `TagsOnTodos_tagId_fkey` (`tagId`),
  CONSTRAINT `TagsOnTodos_tagId_fkey` FOREIGN KEY (`tagId`) REFERENCES `tag` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TagsOnTodos_todoId_fkey` FOREIGN KEY (`todoId`) REFERENCES `todo` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagsontodos`
--

LOCK TABLES `tagsontodos` WRITE;
/*!40000 ALTER TABLE `tagsontodos` DISABLE KEYS */;
INSERT INTO `tagsontodos` VALUES (21,13,'2025-12-26 07:06:13.646','cmkarwq5v0003b47kn18mszur'),(21,14,'2025-12-26 07:06:13.646','cmkarwq5v0003b47kn18mszur'),(22,14,'2025-12-26 13:54:39.979','cmkarwq5v0003b47kn18mszur'),(22,15,'2025-12-26 13:54:39.979','cmkarwq5v0003b47kn18mszur'),(22,16,'2025-12-26 13:54:39.979','cmkarwq5v0003b47kn18mszur'),(23,14,'2025-12-26 15:25:23.934','cmkarwq5v0003b47kn18mszur'),(23,15,'2025-12-26 15:25:23.934','cmkarwq5v0003b47kn18mszur'),(24,13,'2025-12-26 15:27:39.963','cmkarwq5v0003b47kn18mszur'),(24,19,'2025-12-26 15:27:39.963','cmkarwq5v0003b47kn18mszur'),(25,15,'2025-12-26 15:28:03.651','cmkarwq5v0003b47kn18mszur'),(25,20,'2025-12-26 15:28:03.651','cmkarwq5v0003b47kn18mszur'),(26,16,'2025-12-26 15:29:13.663','cmkarwq5v0003b47kn18mszur'),(26,20,'2025-12-26 15:29:13.663','cmkarwq5v0003b47kn18mszur'),(27,13,'2025-12-26 15:29:42.067','cmkarwq5v0003b47kn18mszur'),(27,20,'2025-12-26 15:29:42.067','cmkarwq5v0003b47kn18mszur'),(28,16,'2025-12-30 07:51:06.134','cmkarwq5v0003b47kn18mszur'),(28,20,'2025-12-30 07:51:06.134','cmkarwq5v0003b47kn18mszur'),(29,21,'2025-12-27 07:02:51.638','cmkarwq5v0003b47kn18mszur'),(30,13,'2025-12-27 07:03:58.599','cmkarwq5v0003b47kn18mszur'),(30,15,'2025-12-27 07:03:58.599','cmkarwq5v0003b47kn18mszur'),(31,15,'2025-12-27 10:10:14.285','cmkarwq5v0003b47kn18mszur'),(36,20,'2025-12-30 08:08:48.112','cmkarwq5v0003b47kn18mszur'),(36,22,'2025-12-30 08:08:48.112','cmkarwq5v0003b47kn18mszur'),(37,23,'2026-01-13 02:32:08.826','cmkarwq5v0003b47kn18mszur'),(38,23,'2025-12-31 04:58:48.390','cmkarwq5v0003b47kn18mszur'),(39,20,'2026-01-13 02:03:04.072','cmkarwq5v0003b47kn18mszur'),(39,24,'2026-01-13 02:03:04.072','cmkarwq5v0003b47kn18mszur'),(40,20,'2026-01-13 02:05:14.202','cmkarwq5v0003b47kn18mszur'),(40,24,'2026-01-13 02:05:14.203','cmkarwq5v0003b47kn18mszur'),(41,24,'2026-01-13 02:06:12.713','cmkarwq5v0003b47kn18mszur'),(41,25,'2026-01-13 02:06:12.713','cmkarwq5v0003b47kn18mszur'),(42,24,'2026-01-13 02:07:23.988','cmkarwq5v0003b47kn18mszur'),(43,16,'2026-01-13 02:14:51.394','cmkarwq5v0003b47kn18mszur'),(43,20,'2026-01-13 02:14:51.394','cmkarwq5v0003b47kn18mszur'),(43,24,'2026-01-13 02:14:51.394','cmkarwq5v0003b47kn18mszur'),(44,13,'2026-01-13 02:13:45.404','cmkarwq5v0003b47kn18mszur'),(44,20,'2026-01-13 02:13:45.404','cmkarwq5v0003b47kn18mszur'),(44,24,'2026-01-13 02:13:45.404','cmkarwq5v0003b47kn18mszur'),(45,23,'2026-01-13 02:31:45.170','cmkarwq5v0003b47kn18mszur'),(45,27,'2026-01-13 02:31:45.170','cmkarwq5v0003b47kn18mszur'),(46,15,'2026-01-13 02:54:25.273','cmkarwq5v0003b47kn18mszur'),(46,16,'2026-01-13 02:54:25.273','cmkarwq5v0003b47kn18mszur'),(46,20,'2026-01-13 02:54:25.273','cmkarwq5v0003b47kn18mszur'),(47,15,'2026-01-13 03:28:54.135','cmkarwq5v0003b47kn18mszur'),(47,16,'2026-01-13 03:28:54.135','cmkarwq5v0003b47kn18mszur'),(47,20,'2026-01-13 03:28:54.135','cmkarwq5v0003b47kn18mszur'),(48,23,'2026-01-13 10:11:19.396','cmkarwq5v0003b47kn18mszur'),(48,29,'2026-01-13 10:11:19.396','cmkarwq5v0003b47kn18mszur'),(49,20,'2026-01-14 13:09:15.713','cmkarwq5v0003b47kn18mszur'),(49,28,'2026-01-14 13:09:15.713','cmkarwq5v0003b47kn18mszur'),(50,13,'2026-01-14 14:37:03.734','cmkarwq5v0003b47kn18mszur'),(50,20,'2026-01-14 14:37:03.734','cmkarwq5v0003b47kn18mszur'),(51,16,'2026-01-15 01:41:53.875','cmkarwq5v0003b47kn18mszur'),(51,20,'2026-01-15 01:41:53.875','cmkarwq5v0003b47kn18mszur'),(52,16,'2026-01-15 01:42:39.507','cmkarwq5v0003b47kn18mszur'),(52,20,'2026-01-15 01:42:39.507','cmkarwq5v0003b47kn18mszur'),(52,36,'2026-01-15 01:42:39.507','cmkarwq5v0003b47kn18mszur'),(53,13,'2026-01-15 11:50:48.281','cmkarwq5v0003b47kn18mszur'),(53,37,'2026-01-15 11:50:48.281','cmkarwq5v0003b47kn18mszur'),(54,15,'2026-01-15 11:52:31.875','cmkarwq5v0003b47kn18mszur'),(54,37,'2026-01-15 11:52:31.875','cmkarwq5v0003b47kn18mszur'),(55,23,'2026-01-15 11:53:23.713','cmkarwq5v0003b47kn18mszur'),(56,38,'2026-01-17 03:36:59.531','cmkarwq5v0003b47kn18mszur'),(57,23,'2026-01-17 07:39:27.035','cmkarwq5v0003b47kn18mszur'),(57,39,'2026-01-17 07:39:27.035','cmkarwq5v0003b47kn18mszur'),(58,20,'2026-01-17 13:29:45.081','cmkarwq5v0003b47kn18mszur'),(58,40,'2026-01-17 13:29:45.081','cmkarwq5v0003b47kn18mszur'),(59,20,'2026-01-18 02:52:38.437','cmkarwq5v0003b47kn18mszur'),(59,41,'2026-01-18 02:52:38.437','cmkarwq5v0003b47kn18mszur'),(60,20,'2026-01-18 02:56:29.719','cmkarwq5v0003b47kn18mszur'),(60,42,'2026-01-18 02:56:29.719','cmkarwq5v0003b47kn18mszur'),(61,20,'2026-01-18 02:59:57.139','cmkarwq5v0003b47kn18mszur'),(62,23,'2026-01-18 09:23:36.900','cmkarwq5v0003b47kn18mszur'),(62,43,'2026-01-18 09:23:36.900','cmkarwq5v0003b47kn18mszur'),(63,21,'2026-01-18 09:24:10.639','cmkarwq5v0003b47kn18mszur'),(63,23,'2026-01-18 09:24:10.639','cmkarwq5v0003b47kn18mszur'),(64,23,'2026-01-21 02:53:39.758','cmkarwq5v0003b47kn18mszur'),(64,46,'2026-01-21 02:53:39.758','cmkarwq5v0003b47kn18mszur'),(65,23,'2026-01-21 02:54:25.881','cmkarwq5v0003b47kn18mszur'),(65,46,'2026-01-21 02:54:25.881','cmkarwq5v0003b47kn18mszur'),(65,47,'2026-01-21 02:54:25.881','cmkarwq5v0003b47kn18mszur'),(66,46,'2026-01-21 14:02:42.109','cmkarwq5v0003b47kn18mszur'),(66,47,'2026-01-21 14:02:42.109','cmkarwq5v0003b47kn18mszur'),(66,48,'2026-01-21 14:02:42.109','cmkarwq5v0003b47kn18mszur'),(67,16,'2026-01-22 00:22:33.833','cmkarwq5v0003b47kn18mszur'),(67,37,'2026-01-22 00:22:33.833','cmkarwq5v0003b47kn18mszur'),(68,47,'2026-01-22 12:35:56.563','cmkarwq5v0003b47kn18mszur'),(68,48,'2026-01-22 12:35:56.563','cmkarwq5v0003b47kn18mszur'),(69,20,'2026-01-22 12:36:32.539','cmkarwq5v0003b47kn18mszur'),(69,48,'2026-01-22 12:36:32.539','cmkarwq5v0003b47kn18mszur'),(70,23,'2026-01-23 06:16:52.973','cmkarwq5v0003b47kn18mszur'),(70,50,'2026-01-23 06:16:52.973','cmkarwq5v0003b47kn18mszur'),(71,50,'2026-01-23 06:17:15.280','cmkarwq5v0003b47kn18mszur'),(72,51,'2026-01-23 10:18:47.233','cmkarwq5v0003b47kn18mszur'),(72,52,'2026-01-23 10:18:47.233','cmkarwq5v0003b47kn18mszur'),(73,23,'2026-01-23 12:13:57.581','cmkarwq5v0003b47kn18mszur'),(73,39,'2026-01-23 12:13:57.581','cmkarwq5v0003b47kn18mszur'),(74,23,'2026-01-23 13:10:14.366','cmkarwq5v0003b47kn18mszur'),(74,50,'2026-01-23 13:10:14.366','cmkarwq5v0003b47kn18mszur'),(75,50,'2026-01-23 13:10:39.639','cmkarwq5v0003b47kn18mszur'),(76,51,'2026-01-23 14:18:09.763','cmkarwq5v0003b47kn18mszur'),(76,52,'2026-01-23 14:18:09.763','cmkarwq5v0003b47kn18mszur'),(77,13,'2026-01-25 08:43:37.379','cmkarwq5v0003b47kn18mszur'),(77,53,'2026-01-25 08:43:37.379','cmkarwq5v0003b47kn18mszur'),(77,55,'2026-01-25 08:43:37.379','cmkarwq5v0003b47kn18mszur'),(78,16,'2026-01-25 12:24:17.957','cmkarwq5v0003b47kn18mszur'),(78,53,'2026-01-25 12:24:17.957','cmkarwq5v0003b47kn18mszur'),(78,55,'2026-01-25 12:24:17.957','cmkarwq5v0003b47kn18mszur'),(79,58,'2026-01-26 01:13:01.984','cmkarwq5v0003b47kn18mszur'),(80,58,'2026-01-26 01:13:40.096','cmkarwq5v0003b47kn18mszur'),(81,59,'2026-01-27 11:43:28.923','cmkarwq5v0003b47kn18mszur'),(81,60,'2026-01-27 11:43:28.923','cmkarwq5v0003b47kn18mszur'),(82,59,'2026-01-27 11:44:13.605','cmkarwq5v0003b47kn18mszur'),(82,61,'2026-01-27 11:44:13.605','cmkarwq5v0003b47kn18mszur'),(83,59,'2026-01-27 11:45:03.646','cmkarwq5v0003b47kn18mszur'),(83,62,'2026-01-27 11:45:03.646','cmkarwq5v0003b47kn18mszur'),(84,22,'2026-01-28 12:54:24.450','cmkarwq5v0003b47kn18mszur'),(84,58,'2026-01-28 12:54:24.450','cmkarwq5v0003b47kn18mszur'),(85,63,'2026-01-28 12:55:05.583','cmkarwq5v0003b47kn18mszur'),(85,64,'2026-01-28 12:55:05.583','cmkarwq5v0003b47kn18mszur'),(86,63,'2026-01-28 12:55:28.269','cmkarwq5v0003b47kn18mszur'),(86,64,'2026-01-28 12:55:28.269','cmkarwq5v0003b47kn18mszur'),(87,63,'2026-01-28 12:55:39.284','cmkarwq5v0003b47kn18mszur'),(87,64,'2026-01-28 12:55:39.284','cmkarwq5v0003b47kn18mszur');
/*!40000 ALTER TABLE `tagsontodos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeline`
--

DROP TABLE IF EXISTS `timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timeline` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storyline` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Timeline_userId_fkey` (`userId`),
  CONSTRAINT `Timeline_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeline`
--

LOCK TABLES `timeline` WRITE;
/*!40000 ALTER TABLE `timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timelineitem`
--

DROP TABLE IF EXISTS `timelineitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timelineitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timelineId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TimelineItem_timelineId_id_idx` (`timelineId`,`id`),
  KEY `TimelineItem_createdById_fkey` (`createdById`),
  CONSTRAINT `TimelineItem_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TimelineItem_timelineId_fkey` FOREIGN KEY (`timelineId`) REFERENCES `timeline` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timelineitem`
--

LOCK TABLES `timelineitem` WRITE;
/*!40000 ALTER TABLE `timelineitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `timelineitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timelinepartner`
--

DROP TABLE IF EXISTS `timelinepartner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timelinepartner` (
  `timelineItemId` int NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`timelineItemId`,`userId`),
  KEY `TimelinePartner_userId_idx` (`userId`),
  CONSTRAINT `TimelinePartner_timelineItemId_fkey` FOREIGN KEY (`timelineItemId`) REFERENCES `timelineitem` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TimelinePartner_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timelinepartner`
--

LOCK TABLES `timelinepartner` WRITE;
/*!40000 ALTER TABLE `timelinepartner` DISABLE KEYS */;
/*!40000 ALTER TABLE `timelinepartner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `todo`
--

DROP TABLE IF EXISTS `todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT '0',
  `createAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  `finishedAt` datetime(3) NOT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Todo_userId_fkey` (`userId`),
  CONSTRAINT `Todo_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todo`
--

LOCK TABLES `todo` WRITE;
/*!40000 ALTER TABLE `todo` DISABLE KEYS */;
INSERT INTO `todo` VALUES (2,'test add todo',0,'2025-12-24 12:12:01.966','2025-12-26 07:05:31.496','2025-12-26 07:05:31.496',1,'cmkarwq5v0003b47kn18mszur'),(3,'test add multi tags',0,'2025-12-24 12:14:02.013','2025-12-26 07:05:31.023','2025-12-26 07:05:31.023',1,'cmkarwq5v0003b47kn18mszur'),(4,'test add exist tags',0,'2025-12-24 12:14:56.283','2025-12-24 12:54:17.020','2025-12-24 12:54:17.020',1,'cmkarwq5v0003b47kn18mszur'),(5,'123231',0,'2025-12-24 12:15:26.054','2025-12-24 12:54:24.143','2025-12-24 12:54:24.143',1,'cmkarwq5v0003b47kn18mszur'),(6,'123',0,'2025-12-24 12:15:44.178','2025-12-26 07:05:30.532','2025-12-26 07:05:30.532',1,'cmkarwq5v0003b47kn18mszur'),(7,'321',0,'2025-12-24 12:16:01.818','2025-12-25 14:07:40.195','2025-12-25 14:07:40.195',1,'cmkarwq5v0003b47kn18mszur'),(8,'123',1,'2025-12-24 12:16:15.785','2025-12-25 08:13:48.035','2025-12-25 08:13:48.035',1,'cmkarwq5v0003b47kn18mszur'),(9,'123',0,'2025-12-24 12:17:56.859','2025-12-24 12:54:19.219','2025-12-24 12:54:19.219',1,'cmkarwq5v0003b47kn18mszur'),(10,'tes',1,'2025-12-24 12:18:46.058','2025-12-24 12:54:28.794','2025-12-24 12:54:28.794',1,'cmkarwq5v0003b47kn18mszur'),(11,'123',0,'2025-12-24 12:21:34.188','2025-12-24 12:54:15.278','2025-12-24 12:54:15.278',1,'cmkarwq5v0003b47kn18mszur'),(12,'123312',1,'2025-12-24 12:23:23.824','2025-12-25 08:13:47.665','2025-12-25 08:13:47.665',1,'cmkarwq5v0003b47kn18mszur'),(13,'123',1,'2025-12-24 12:40:31.312','2025-12-25 08:13:47.105','2025-12-25 08:13:47.105',1,'cmkarwq5v0003b47kn18mszur'),(14,'123',0,'2025-12-24 12:40:43.933','2025-12-24 12:54:13.220','2025-12-24 12:54:13.220',1,'cmkarwq5v0003b47kn18mszur'),(15,'111',0,'2025-12-24 12:40:57.828','2025-12-24 12:45:39.107','2025-12-24 12:45:39.107',1,'cmkarwq5v0003b47kn18mszur'),(16,'1232123123',1,'2025-12-25 14:14:53.556','2025-12-26 07:05:30.144','2025-12-26 07:05:30.144',1,'cmkarwq5v0003b47kn18mszur'),(17,'123 add ',0,'2025-12-25 14:15:47.019','2025-12-26 07:05:29.663','2025-12-26 07:05:29.663',1,'cmkarwq5v0003b47kn18mszur'),(18,'test add multi tags',0,'2025-12-25 14:19:55.300','2025-12-26 07:05:29.217','2025-12-26 07:05:29.217',1,'cmkarwq5v0003b47kn18mszur'),(19,'1231',0,'2025-12-25 14:49:01.652','2025-12-26 07:05:24.546','2025-12-26 07:05:24.546',1,'cmkarwq5v0003b47kn18mszur'),(20,'111',1,'2025-12-25 14:50:50.643','2025-12-26 07:05:23.536','2025-12-26 07:05:23.536',1,'cmkarwq5v0003b47kn18mszur'),(21,'TodoEditor代码优化',1,'2025-12-26 07:06:13.650','2025-12-26 07:06:15.303','2025-12-26 07:06:15.303',0,'cmkarwq5v0003b47kn18mszur'),(22,'Blog 添加 tag 及 tag 编辑面板',1,'2025-12-26 13:54:39.986','2025-12-27 10:12:54.659','2025-12-27 10:12:54.659',0,'cmkarwq5v0003b47kn18mszur'),(23,'tag 增加常用建议',1,'2025-12-26 15:25:23.935','2026-01-14 14:35:22.279','2026-01-14 14:35:22.279',0,'cmkarwq5v0003b47kn18mszur'),(24,'todo 增加目标模式，这种模式下，会设定最终目标，每次完成该 todo 都会提示添加该目标的下一步骤，即创建新的 todo。',0,'2025-12-26 15:27:39.964','2025-12-26 15:27:39.964','2025-12-26 15:27:39.964',0,'cmkarwq5v0003b47kn18mszur'),(25,'增加 tag 列表页',1,'2025-12-26 15:28:03.653','2026-01-13 13:14:55.391','2026-01-13 13:14:55.391',0,'cmkarwq5v0003b47kn18mszur'),(26,'blog 页面添加编辑栏，支持删除，收藏等操作。',1,'2025-12-26 15:29:13.664','2026-01-14 14:35:17.713','2026-01-14 14:35:17.713',0,'cmkarwq5v0003b47kn18mszur'),(27,'todo 页面增加搜索栏，支持筛选等操作',1,'2025-12-26 15:29:42.068','2025-12-27 15:56:32.262','2025-12-27 15:56:32.262',0,'cmkarwq5v0003b47kn18mszur'),(28,'blog 列表页面添加搜索栏，支持筛选等操作。',1,'2025-12-26 15:30:39.466','2025-12-30 07:51:07.937','2025-12-30 07:51:07.937',0,'cmkarwq5v0003b47kn18mszur'),(29,'日期组件实现 - 初始框架搭建',1,'2025-12-27 07:02:51.642','2026-01-22 12:25:52.989','2026-01-22 12:25:52.989',0,'cmkarwq5v0003b47kn18mszur'),(30,'todo 增加“优先级” tag',0,'2025-12-27 07:03:58.600','2025-12-27 07:03:58.600','2025-12-27 07:03:58.600',0,'cmkarwq5v0003b47kn18mszur'),(31,'大小写敏感测试 Tag',0,'2025-12-27 10:10:14.288','2025-12-27 10:12:30.594','2025-12-27 10:12:30.594',1,'cmkarwq5v0003b47kn18mszur'),(32,'添加测试2',0,'2025-12-27 10:10:43.076','2025-12-27 10:12:29.070','2025-12-27 10:12:29.070',1,'cmkarwq5v0003b47kn18mszur'),(33,'tag 测试1',0,'2025-12-27 10:10:51.205','2025-12-27 10:12:28.187','2025-12-27 10:12:28.187',1,'cmkarwq5v0003b47kn18mszur'),(34,'tag 1',0,'2025-12-27 10:11:09.830','2025-12-27 10:12:27.197','2025-12-27 10:12:27.197',1,'cmkarwq5v0003b47kn18mszur'),(35,'123',0,'2025-12-27 12:52:29.505','2025-12-27 12:52:31.809','2025-12-27 12:52:31.809',1,'cmkarwq5v0003b47kn18mszur'),(36,'重新调整主要布局容器,考虑让每个页面自主决定篇幅的使用。',1,'2025-12-30 08:08:48.114','2026-01-17 13:02:10.623','2026-01-17 13:02:10.623',0,'cmkarwq5v0003b47kn18mszur'),(37,'抽屉式内容展示',0,'2025-12-31 04:54:18.442','2026-01-13 02:32:08.827','2026-01-13 02:32:08.827',0,'cmkarwq5v0003b47kn18mszur'),(38,'不规则图片框',0,'2025-12-31 04:58:48.391','2025-12-31 04:58:48.391','2025-12-31 04:58:48.391',0,'cmkarwq5v0003b47kn18mszur'),(39,'登录页面',1,'2026-01-13 02:03:04.073','2026-01-13 02:04:51.021','2026-01-13 02:04:51.021',0,'cmkarwq5v0003b47kn18mszur'),(40,'注册页面',1,'2026-01-13 02:05:14.204','2026-01-13 02:05:15.579','2026-01-13 02:05:15.579',0,'cmkarwq5v0003b47kn18mszur'),(41,'鉴权相关接口：登录/注册/用户信息/登出',1,'2026-01-13 02:06:12.714','2026-01-13 02:06:16.889','2026-01-13 02:06:16.889',0,'cmkarwq5v0003b47kn18mszur'),(42,'鉴权功能：权限检查方法/权限组件/权限中间件',1,'2026-01-13 02:07:23.988','2026-01-13 02:07:25.359','2026-01-13 02:07:25.359',0,'cmkarwq5v0003b47kn18mszur'),(43,'博客相关页面改造及鉴权添加',1,'2026-01-13 02:08:15.670','2026-01-13 02:14:51.395','2026-01-13 02:14:51.395',0,'cmkarwq5v0003b47kn18mszur'),(44,'todo 相关页面改造及鉴权添加',1,'2026-01-13 02:13:45.405','2026-01-13 02:20:26.367','2026-01-13 02:20:26.367',0,'cmkarwq5v0003b47kn18mszur'),(45,'时间线组件',0,'2026-01-13 02:31:45.171','2026-01-13 02:31:45.171','2026-01-13 02:31:45.171',0,'cmkarwq5v0003b47kn18mszur'),(46,'blog 编辑页增加 tag 编辑菜单',1,'2026-01-13 02:54:25.276','2026-01-13 03:28:13.661','2026-01-13 03:28:13.661',0,'cmkarwq5v0003b47kn18mszur'),(47,'blog 列表页支持 tag 显示',1,'2026-01-13 03:28:54.137','2026-01-13 03:28:55.874','2026-01-13 03:28:55.874',0,'cmkarwq5v0003b47kn18mszur'),(48,'进度条组件',1,'2026-01-13 10:11:19.400','2026-01-14 06:16:55.536','2026-01-14 06:16:55.536',0,'cmkarwq5v0003b47kn18mszur'),(49,'测试用',1,'2026-01-14 09:07:39.912','2026-01-14 13:09:15.715','2026-01-14 13:09:15.715',0,'cmkarwq5v0003b47kn18mszur'),(50,'todo 列表增加按更新时间排序',0,'2026-01-14 14:37:03.735','2026-01-14 14:37:03.735','2026-01-14 14:37:03.735',0,'cmkarwq5v0003b47kn18mszur'),(51,'blog 页面增加点赞，收藏，分享等功能',1,'2026-01-15 01:41:53.879','2026-01-15 04:15:32.740','2026-01-15 04:15:32.740',0,'cmkarwq5v0003b47kn18mszur'),(52,'blog 页面增加评论功能',0,'2026-01-15 01:42:39.508','2026-01-15 01:42:39.508','2026-01-15 01:42:39.508',0,'cmkarwq5v0003b47kn18mszur'),(53,'todo 禁止编辑提示优化',1,'2026-01-15 11:50:48.283','2026-01-17 13:02:03.534','2026-01-17 13:02:03.534',0,'cmkarwq5v0003b47kn18mszur'),(54,'tag 展示增加抽屉效果',1,'2026-01-15 11:52:31.876','2026-01-17 13:01:54.118','2026-01-17 13:01:54.118',0,'cmkarwq5v0003b47kn18mszur'),(55,'个人展示卡片',1,'2026-01-15 11:53:23.713','2026-01-22 12:26:05.386','2026-01-22 12:26:05.386',0,'cmkarwq5v0003b47kn18mszur'),(56,'公司问题处理',0,'2026-01-17 03:36:59.536','2026-01-17 07:37:02.125','2026-01-17 07:37:02.125',0,'cmkarwq5v0003b47kn18mszur'),(57,'弹窗逻辑优化',1,'2026-01-17 07:39:27.037','2026-01-17 13:00:08.135','2026-01-17 13:00:08.135',0,'cmkarwq5v0003b47kn18mszur'),(58,'番茄时钟-网页版',0,'2026-01-17 13:29:45.083','2026-01-17 13:29:45.083','2026-01-17 13:29:45.083',0,'cmkarwq5v0003b47kn18mszur'),(59,'contact 页面',1,'2026-01-18 02:52:38.441','2026-01-22 12:26:13.398','2026-01-22 12:26:13.398',0,'cmkarwq5v0003b47kn18mszur'),(60,'首页',0,'2026-01-18 02:56:29.720','2026-01-18 02:56:29.720','2026-01-18 02:56:29.720',0,'cmkarwq5v0003b47kn18mszur'),(61,'添加测试',0,'2026-01-18 02:59:57.139','2026-01-18 02:59:57.139','2026-01-18 02:59:57.139',0,'cmkarwq5v0003b47kn18mszur'),(62,'天气组件',0,'2026-01-18 09:23:36.902','2026-01-18 09:23:36.902','2026-01-18 09:23:36.902',0,'cmkarwq5v0003b47kn18mszur'),(63,'日历组件',1,'2026-01-18 09:24:10.641','2026-01-22 12:26:17.689','2026-01-22 12:26:17.689',0,'cmkarwq5v0003b47kn18mszur'),(64,'每日状态组件',1,'2026-01-21 02:53:39.761','2026-01-21 14:01:06.790','2026-01-21 14:01:06.790',0,'cmkarwq5v0003b47kn18mszur'),(65,'每周状态统计组件',1,'2026-01-21 02:54:02.419','2026-01-21 07:10:29.420','2026-01-21 07:10:29.420',0,'cmkarwq5v0003b47kn18mszur'),(66,'添加每日记录功能 - 新增博客，健身，是否登录等',0,'2026-01-21 14:02:18.259','2026-01-21 14:02:42.117','2026-01-21 14:02:42.117',0,'cmkarwq5v0003b47kn18mszur'),(67,'博客页面优化 - 增加底部导航，如跳转到下一篇，或者推荐相同 tag 的博客',1,'2026-01-22 00:22:33.837','2026-01-22 12:25:46.371','2026-01-22 12:25:46.371',0,'cmkarwq5v0003b47kn18mszur'),(68,'每日状态统计项目重新调整',0,'2026-01-22 12:35:56.566','2026-01-22 12:35:56.566','2026-01-22 12:35:56.566',0,'cmkarwq5v0003b47kn18mszur'),(69,'健身项目管理页面',0,'2026-01-22 12:36:32.541','2026-01-23 09:51:38.431','2026-01-23 09:51:38.431',0,'cmkarwq5v0003b47kn18mszur'),(70,'主题切换按钮',1,'2026-01-23 06:16:52.983','2026-01-23 10:17:31.082','2026-01-23 10:17:31.082',0,'cmkarwq5v0003b47kn18mszur'),(71,'主题切换功能',1,'2026-01-23 06:17:15.281','2026-01-23 12:41:56.897','2026-01-23 12:41:56.897',0,'cmkarwq5v0003b47kn18mszur'),(72,'CI/CD 流水线',1,'2026-01-23 10:18:47.237','2026-01-24 13:21:19.726','2026-01-24 13:21:19.726',0,'cmkarwq5v0003b47kn18mszur'),(73,'修复弹窗动画问题',0,'2026-01-23 12:13:57.586','2026-01-23 12:13:57.586','2026-01-23 12:13:57.586',0,'cmkarwq5v0003b47kn18mszur'),(74,'button 组件 primary 等状态颜色配置主题色',0,'2026-01-23 13:10:14.370','2026-01-23 13:10:14.370','2026-01-23 13:10:14.370',0,'cmkarwq5v0003b47kn18mszur'),(75,'每个主题按钮设置为自己主题颜色',1,'2026-01-23 13:10:39.640','2026-01-25 08:26:23.431','2026-01-25 08:26:23.431',0,'cmkarwq5v0003b47kn18mszur'),(76,'CI/CD 阶段1 —— 自动部署到云服务器',1,'2026-01-23 14:18:09.765','2026-01-25 07:15:20.012','2026-01-25 07:15:20.012',0,'cmkarwq5v0003b47kn18mszur'),(77,'Todo 接口权限调整',1,'2026-01-25 08:37:27.647','2026-01-25 12:23:59.844','2026-01-25 12:23:59.844',0,'cmkarwq5v0003b47kn18mszur'),(78,'blog 接口权限调整',1,'2026-01-25 12:24:17.969','2026-01-25 13:57:11.725','2026-01-25 13:57:11.725',0,'cmkarwq5v0003b47kn18mszur'),(79,'超级时间线基本布局',0,'2026-01-26 01:13:01.994','2026-01-26 01:13:01.994','2026-01-26 01:13:01.994',0,'cmkarwq5v0003b47kn18mszur'),(80,'超级时间线-无限日期',0,'2026-01-26 01:13:40.097','2026-01-26 01:13:40.097','2026-01-26 01:13:40.097',0,'cmkarwq5v0003b47kn18mszur'),(81,'TypeScript 知识点速查',1,'2026-01-27 11:43:28.924','2026-01-27 11:43:32.058','2026-01-27 11:43:32.058',0,'cmkarwq5v0003b47kn18mszur'),(82,'React 知识点速查',0,'2026-01-27 11:44:13.606','2026-01-27 11:44:13.606','2026-01-27 11:44:13.606',0,'cmkarwq5v0003b47kn18mszur'),(83,'项目工程化知识点速查',0,'2026-01-27 11:45:03.647','2026-01-27 11:45:03.647','2026-01-27 11:45:03.647',0,'cmkarwq5v0003b47kn18mszur'),(84,'超级时间线连线部分',0,'2026-01-28 12:54:24.463','2026-01-28 12:54:24.463','2026-01-28 12:54:24.463',0,'cmkarwq5v0003b47kn18mszur'),(85,'个人工作经历和项目整理',0,'2026-01-28 12:55:05.583','2026-01-28 12:55:05.583','2026-01-28 12:55:05.583',0,'cmkarwq5v0003b47kn18mszur'),(86,'简历更新',0,'2026-01-28 12:55:28.270','2026-01-28 12:55:28.270','2026-01-28 12:55:28.270',0,'cmkarwq5v0003b47kn18mszur'),(87,'看面试直播',0,'2026-01-28 12:55:39.285','2026-01-28 12:55:39.285','2026-01-28 12:55:39.285',0,'cmkarwq5v0003b47kn18mszur');
/*!40000 ALTER TABLE `todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('USER','ADMIN','ROOT','VISITOR') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updateAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_key` (`email`),
  UNIQUE KEY `users_phone_key` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('cmkarwq5v0003b47kn18mszur','zxf_tech@outlook.com',NULL,'Feline','$2b$12$bRXdt3tINLqTwF5SDXvK3OPhPuf.ofNutmlkBa7BtaxnUBeaYciYW',NULL,NULL,'ROOT','2026-01-12 06:19:55.121','2026-01-12 06:19:55.121'),('cmkse9asd0000s87kzry233ly','123',NULL,'123','$2b$12$UHpfkxb3Mn6iZR5WoscQqeUMppp9cM2RXextpfteCiwUrRrDe7Ui2',NULL,NULL,'USER','2026-01-24 14:17:38.267','2026-01-24 14:17:38.267');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_tokens` (
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`identifier`,`token`),
  UNIQUE KEY `verification_tokens_token_key` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workoutitem`
--

DROP TABLE IF EXISTS `workoutitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workoutitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dailyStatId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `exerciseId` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WorkoutItem_dailyStatId_exerciseId_key` (`dailyStatId`,`exerciseId`),
  CONSTRAINT `WorkoutItem_dailyStatId_fkey` FOREIGN KEY (`dailyStatId`) REFERENCES `dailystat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workoutitem`
--

LOCK TABLES `workoutitem` WRITE;
/*!40000 ALTER TABLE `workoutitem` DISABLE KEYS */;
INSERT INTO `workoutitem` VALUES (17,'全身锻练',5,'2026-01-21 02:41:33.955',17),(21,'全身锻练',6,'2026-01-21 07:42:41.408',17),(22,'全身锻练',7,'2026-01-21 08:02:19.726',17),(24,'俯卧撑',7,'2026-01-22 12:30:30.640',24),(25,'俯卧撑',8,'2026-01-22 12:34:42.039',24);
/*!40000 ALTER TABLE `workoutitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workoutset`
--

DROP TABLE IF EXISTS `workoutset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workoutset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reps` int DEFAULT NULL,
  `order` int DEFAULT NULL,
  `workoutItemId` int NOT NULL,
  `duration` int NOT NULL,
  `weight` double DEFAULT NULL,
  `calories` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `WorkoutSet_workoutItemId_fkey` (`workoutItemId`),
  CONSTRAINT `WorkoutSet_workoutItemId_fkey` FOREIGN KEY (`workoutItemId`) REFERENCES `workoutitem` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workoutset`
--

LOCK TABLES `workoutset` WRITE;
/*!40000 ALTER TABLE `workoutset` DISABLE KEYS */;
INSERT INTO `workoutset` VALUES (31,20,1,17,30,NULL,0),(32,20,2,17,30,NULL,0),(33,20,1,17,30,NULL,0),(34,20,2,17,30,NULL,0),(35,20,1,17,30,NULL,0),(36,20,2,17,30,NULL,0),(37,20,1,17,30,NULL,0),(38,20,2,17,30,NULL,0),(39,20,1,21,30,NULL,0),(40,20,2,21,30,NULL,0),(41,20,2,22,30,NULL,300),(42,20,2,22,30,NULL,300),(43,20,2,22,30,NULL,300),(44,20,2,22,30,NULL,300),(45,20,3,24,2,NULL,30),(46,20,3,24,2,NULL,30),(47,20,3,24,2,NULL,30),(48,20,3,25,2,NULL,30),(49,20,3,25,2,NULL,30),(50,20,3,25,2,NULL,30);
/*!40000 ALTER TABLE `workoutset` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29 14:12:39
